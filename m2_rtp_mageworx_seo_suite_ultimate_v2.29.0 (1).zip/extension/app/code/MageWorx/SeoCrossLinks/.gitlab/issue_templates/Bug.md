#### Preconditions (*)

(Provide the exact Magento and Extension versions and any important information on the environment where bug is reproducible.)


#### Steps to reproduce (*)

(Provide a set of clear steps to reproduce this bug.)


#### Expected result (*)

(Tell us what do you expect to happen - screenshots, logs or description)


#### Actual result (*)

(Tell us what happened instead. Include error messages and issues.)


#### Possible fixes

(If you can, link to the line of code that might be responsible for the problem)

/label ~bug
