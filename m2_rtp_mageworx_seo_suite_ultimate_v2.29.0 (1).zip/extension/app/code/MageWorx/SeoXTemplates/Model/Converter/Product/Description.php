<?php
/**
 * Copyright © 2016 MageWorx. All rights reserved.
 * See LICENSE.txt for license details.
 */

namespace MageWorx\SeoXTemplates\Model\Converter\Product;

use MageWorx\SeoXTemplates\Model\Converter\Product as ConverterProduct;

class Description extends ConverterProduct
{
    /**
     *
     * @param string $converValue
     * @return string
     */
    protected function _render($convertValue)
    {
        return parent::_render($convertValue);
    }
}
