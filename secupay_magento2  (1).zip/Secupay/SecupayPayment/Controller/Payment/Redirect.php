<?php

namespace Secupay\SecupayPayment\Controller\Payment;

use Secupay\SecupayPayment\Controller\ProcessController;
use Secupay\SecupayPayment\Helper\Lang;

/**
 * Class Redirect
 * @package Secupay\SecupayPayment\Controller\Payment
 */
class Redirect extends ProcessController
{
    public function execute()
    {
        // Load the order
        $order = $this->getOrder();
        $transId = $order->getPayment()->getAdditionalInformation('secupay_transaction_id');

        // Leave a comment into the order status history
        $comment = sprintf(__(Lang::REDIRECT), $transId, date('d.m.Y H:i:s'));
        $order->addStatusHistoryComment($comment);
        $order->save();

        // Render the payment checkout page
        $resultPage = $this->resultPageFactory->create();
        $resultPage->getConfig()->getTitle()->prepend(__(Lang::PAY_NOW));

        $this->_view->loadLayout();
        $this->_view->renderLayout();
    }
}