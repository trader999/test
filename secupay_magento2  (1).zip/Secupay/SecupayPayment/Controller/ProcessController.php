<?php

namespace Secupay\SecupayPayment\Controller;

use Magento\Checkout\Model\Session;
use Magento\Framework\App\Action\Context;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\App\Action\Action;
use Magento\Framework\View\Result\PageFactory;
use Magento\Sales\Model\Order;
use Psr\Log\LoggerInterface;
use Secupay\SecupayPayment\Model\DbConnector;

/**
 * Class ProcessController
 * @package Secupay\SecupayPayment\Controller
 */
abstract class ProcessController extends Action
{
    const low_ip = '91.195.150.0';
    const high_ip = '91.195.151.255';

    /**
     * @var DbConnector
     */
    protected $db;

    /**
     * @var
     */
    protected $_checkoutSession;

    /**
     * @var
     */
    protected $order;

    /**
     * @var
     */
    protected $requestOrderId;

    /**
     * @var \Psr\Log\LoggerInterface
     */
    protected $logger;

    /**
     * @var \Magento\Framework\View\Result\PageFactory
     */
    protected $resultPageFactory;

    /**
     * @var array
     */
    protected $_commentMessages = [
        'redirect' => 'Redirection to Secupay AG. Transaction not finished. Transaction ID: [[transaction_id]]. Time: [[date]]',
        'transaction_pending' => 'Transaction not finished. Transaction ID: [[transaction_id]]. Time: [[date]]',
        'received_accepted' => 'The payment has been accepted. Time: [[date]]',
        'abort' => 'Payment aborted. Time: %s',
        'refunded_compensation' => 'Partial amount will be refunded - [[refunded_amount]]. Time: [[date]]',
        'refunded_refunded' => 'Amount will be refunded. Time: [[date]]'
    ];

    /**
     * @var \Magento\Framework\ObjectManagerInterface
     */
    protected $objectManager;

    /**
     * ProcessController constructor.
     * @param Context $context
     * @param PageFactory $resultPageFactory
     * @param LoggerInterface $logger
     */
    public function __construct(Context $context, PageFactory $resultPageFactory, LoggerInterface $logger)
    {
        parent::__construct($context);
        $this->objectManager = $this->_objectManager;
        $this->requestOrderId = $this->getRequest()->getParam('orderId');

        $this->logger = $logger;
        $this->resultPageFactory = $resultPageFactory;
        $this->db = $this->objectManager->get(DbConnector::class);
    }

    /**
     * @inheritdoc
     */
    public function execute()
    {
    }

    /**
     * @return Order
     * @throws LocalizedException
     */
    protected function getOrder()
    {
        if (!is_null($this->order)) {
            return $this->order;
        }

        if (is_null($this->requestOrderId)) {
            $order = $this->objectManager->get(Session::class)->getLastRealOrder();
        } else {
            $order = $this->objectManager->get(Order::class)->loadByIncrementId($this->requestOrderId);
        }

        if (!is_null($order)) {
            $this->order = $order;
            return $order;
        }

        throw new LocalizedException(__('Forbidden'));
    }

    /*
    private function _getSendReceiptEmails()
    {
        return (boolean)$this->_objectManager->get('Magento\Framework\App\Config\ScopeConfigInterface')->getValue(
            'payment/secupay/send_mail',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }
    */

    /*
    private function _getSendOrderConfirmationOption()
    {
        return (boolean)$this->_objectManager->get('Magento\Framework\App\Config\ScopeConfigInterface')->getValue(
            'payment/secupay/send_order_confirmation',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }
    */

    /**
     * Get create creditmemo flag
     *
     * @return boolean
     */
    /*
    private function _getCreateCreditmemoOption()
    {
        // todo Config Option
        return true;
    }
    */

    /**
     * Generates the creditmemo for the current order
     */
    /*
    private function _generateCreditmemo()
    {
        $order = $this->getOrder();

        $this->_generateInvoice();

        if ($order->canCreditmemo()) {

            $creditmemo = $this->_objectManager->get('Magento\Sales\Model\Order\CreditmemoFactory')->createByOrder($order);
            $creditmemoManagement = $this->_objectManager->create(
                'Magento\Sales\Api\CreditmemoManagementInterface'
            );

            $creditmemoManagement->refund($creditmemo, true);

            if ($this->_getSendReceiptEmails()) {
                $creditmemoSender = $this->_objectManager->get('Magento\Sales\Model\Order\Email\Sender\CreditmemoSender');
                $creditmemoSender->send($creditmemo);
            }
        }
    }
    */

    /**
     * Create the creditmemo when configured
     *
     * @param array $statusData
     */
    /*
    private function _handleCreditmemoCreation(array $statusData)
    {
        if ($statusData['status'] === 'refunded'
            && $statusData['reason'] === 'refunded'
            && $this->_getCreateCreditmemoOption()) {
            $this->_generateCreditmemo();
        }
    }
    */
}
