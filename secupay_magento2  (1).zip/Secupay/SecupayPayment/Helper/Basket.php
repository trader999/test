<?php

namespace Secupay\SecupayPayment\Helper;

use Magento\Checkout\Model\Cart;
use Magento\Framework\App\ObjectManager;

/**
 * Class Basket
 * @package Secupay\SecupayPayment\Helper
 */
class Basket
{
    /**
     * @var Cart
     */
    private $cart;

    /**
     * Basket constructor.
     */
    public function __construct()
    {
        $this->cart = ObjectManager::getInstance()->get('Magento\Checkout\Model\Cart');
    }


    /**
     * Function that returns basket information for the API
     *
     * @param @array current basket
     *
     * @return array of items
     */
    public function getBasketInformation()
    {
        /**
         * get Basket Items
         *
         * @var mixed
         */
        $items = $this->cart->getQuote()->getAllVisibleItems();

        $shipping_amount = $this->cart->getQuote()->getShippingAddress()->getShippingInclTax();


        $basket = [];
        if (is_array($items)) {
            foreach ($items as $item) {
                $basket[] = [
                    'name' => $item->getName(),
                    'model' => $item->getSku(),
                    'article_number' => $item->getProductId(),
                    'ean' => '',
                    'item_type' => 'article',
                    'quantity' => (int)$item->getQty(),
                    'price' => (int)($item->getPrice() * 100),
                    'total' => (int)($item->getRowTotalInclTax() * 100),
                    'tax' => (int)($item->getTaxPercent() * 100),
                ];
            }
        }

        if ($shipping_amount > 0) {
            $basket[] = [
                'name' => $this->cart->getQuote()->getShippingAddress()->getShippingMethod(),
                'item_type' => 'shipping',
                'price' => $shipping_amount * 100,
                'total' => $shipping_amount * 100,
                'tax' => $this->cart->getQuote()->getShippingAddress()->getShippingTaxAmount(),
            ];
        }

        return $basket;
    }

    /**
     * @return mixed
     */
    public function getCartId()
    {
        return $this->cart->getQuote()->getId();
    }

}
