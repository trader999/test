<?php

namespace Secupay\SecupayPayment\Helper;

use SecucardConnect\Client\StorageInterface;
use Magento\Framework\App\ObjectManager;

/**
 * Class CacheStorageAdapter
 * @package Secupay\SecupayPayment\Helper
 */
class CacheStorageAdapter implements StorageInterface
{
    /**
     * @var \Magento\Framework\App\CacheInterface
     */
    private $cache;

    /**
     * DummyStorage constructor.
     */
    public function __construct()
    {
        /**
         * @var \Magento\Framework\ObjectManagerInterface $om
         */
        $om = ObjectManager::getInstance();

        /**
         * @var \Magento\Framework\App\CacheInterface $cache
         */
        $this->cache = $om->get('Magento\Framework\App\CacheInterface');
    }

    /**
     * Retrieve an item from cache
     *
     * @param string $key The key to store it under
     *
     * @return mixed
     */
    public function get($key)
    {
        return unserialize($this->cache->load($key));
    }

    /**
     * Set an item in the cache
     *
     * @param string $key
     * @param mixed $value
     *
     * @return self
     */
    public function set($key, $value)
    {
        $this->cache->save(serialize($value), $key);
        return $this;
    }

    /**
     * Remove a key from the cache.
     *
     * @param string $key
     *
     * @return self
     */
    public function delete($key)
    {
        $this->cache->remove($key);
        return $this;
    }

    /**
     * Remove all items from the cache (flush it).
     *
     * @return self
     */
    public function deleteAll()
    {
        $this->cache->clean();
        return $this;
    }
}