<?php

namespace Secupay\SecupayPayment\Helper;

use Magento\Customer\Api\Data\CustomerInterface;
use Magento\Customer\Model\Session as CustomerSession;
use Magento\Framework\Event\ManagerInterface as EventManagerInterface;
use Psr\Log\LoggerInterface as Logger;

class Session
{
    /**
     * @var CustomerSession
     */
    protected $session;

    /**
     * @var EventManagerInterface
     */
    protected $eventManager;

    /**
     * @param Logger $logger
     * @param CustomerSession $session
     * @param EventManagerInterface $eventManager
     */
    public function __construct(
        Logger $logger,
        CustomerSession $session,
        EventManagerInterface $eventManager
    ) {
        $this->session = $session;
        $this->_logger = $logger;
        $this->eventManager = $eventManager;
        $this->_logger->debug(__METHOD__ . ' -> args: ' . json_encode(func_get_args()));
    }

    /**
     * Login customer by data
     *
     * @param CustomerInterface $customerData
     */
    public function login(CustomerInterface $customerData)
    {
        if ($customerData->getId() != $this->session->getId() || !$this->session->isLoggedIn()) {
            $this->dispatchAuthenticationEvent();
            $this->session->setCustomerDataAsLoggedIn($customerData);
            $this->session->regenerateId();
        }
    }

    /**
     * Login customer by id
     *
     * @param integer $customerId
     */
    public function loginById($customerId)
    {
        $this->dispatchAuthenticationEvent();
        $this->session->loginById($customerId);
        $this->session->regenerateId();
    }

    public function getCheckoutSession()
    {
        $this->_logger->debug(__METHOD__ . ' -> args: ' . json_encode(func_get_args()));

        return $this->_checkoutSession;
    }
    /**
     * For compatibility with customer_customer_authenticated event dispatched from standard login controller.
     * The observers are also attached to this with the exception of password related ones.
     *
     * protected function dispatchAuthenticationEvent()
     * {
     * $this->eventManager->dispatch('customer_authenticated');
     * }   */

    /**
     * Set validation credentials in session
     *
     * @param ValidationCredentials $credentials
     *
     * public function setValidationCredentials(ValidationCredentials $credentials)
     * {
     * $this->session->setValidationCredentials($credentials);
     * }   */

    /**
     * Get validation credentials from session
     *
     * @return ValidationCredentials|null
     *
     * public function getValidationCredentials()
     * {
     * $credentials = $this->session->getValidationCredentials();
     *
     * return ($credentials) ?: null;
     * }   */

    /**
     * Check if Magento account is logged in
     *
     * @return bool
     *
     * public function isLoggedIn()
     * {
     * return $this->session->isLoggedIn();
     * }    */

    /**
     * @param Customer $Customer
     *
     * @return void
     *
     * public function setSecupayCustomer(Customer $Customer)
     * {
     * $this->session->setSecupayCustomer($Customer);
     * } */

    /**
     * @return void
     *
     * public function clearCustomer()
     * {
     * $this->session->unsCustomer();
     * }  */

    /**
     * @return Customer|null
     *
     * public function getCustomer()
     * {
     * $Customer = $this->session->getCustomer();
     *
     * if ($Customer && (!$Customer instanceofCustomer)) {
     * $this->clearCustomer();
     * $Customer = null;
     * }
     *
     * return $Customer;
     * }    */
} 
