<?php

namespace Secupay\SecupayPayment\Helper;

use Psr\Log\LoggerInterface;
use Secupay\SecupayPayment\Model\DbConnector;

/**
 * Class TransactionHelper
 * @package Secupay\SecupayPayment\Helper
 */
class TransactionHelper
{

    /**
     * @var LoggerInterface
     */
    private $logger;

    /**
     * @var DbConnector
     */
    private $dbConnector;

    /**
     * @var SecuconnectFactory
     */
    private $clientFactory;

    /**
     * TransactionHelper constructor.
     * @param LoggerInterface $logger
     * @param DbConnector $dbConnector
     * @param SecuconnectFactory $clientFactory
     */
    public function __construct(LoggerInterface $logger, DbConnector $dbConnector, SecuconnectFactory $clientFactory)
    {
        $this->logger = $logger;
        $this->dbConnector = $dbConnector;
        $this->clientFactory = $clientFactory;
    }

    public function setTrackingData($orderId, $tracking = [], $invoiceNumber)
    {
        /*
        $capture_data = [
            'hash' => $data['hash'],
            'payment_method' => $data['payment_type'],
            'tracking_id' => $trackid,
            'carrier' => $carrier,
            'invoice_number' => $this->dbConnector->searchOrder($orderId, 'searchcode'),
        ];

        $res = $this->clientFactory->getSecuconnectClient()->capture($capture_data);
        */
    }

    /**
     * @param $orderId
     *
     * @return array|null
     */
    public function getTransactionData($orderId)
    {
        $data = $this->dbConnector->searchOrder($orderId, ['hash', 'payment_type']);

        if (empty($data['hash'])) {
            return null;
        }

        return $this->clientFactory->getSecuconnectClient()->getPaymentTransactionDetails([
            'payment_method' => $data['payment_type'],
            'hash_id' => $data['hash'],
        ]);
    }
}
