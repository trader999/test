<?php

namespace Secuconnect\Exception;

class NotImplementedException extends \BadFunctionCallException
{

}