<?php

$p = new Phar('secuconnect.phar', FilesystemIterator::CURRENT_AS_FILEINFO | FilesystemIterator::KEY_AS_FILENAME,
    'secuconnect.phar');
$p->startBuffering();
$p->setStub('<?php Phar::mapPhar(); require \'phar://secuconnect.phar/Secuconnect/Client.php\'; __HALT_COMPILER(); ?>');
$p->buildFromDirectory('.', '$(.*)\.php$');
$p->stopBuffering();
echo "Phar created: secuconnect.phar\n";
