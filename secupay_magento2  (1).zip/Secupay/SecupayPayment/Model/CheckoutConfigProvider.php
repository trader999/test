<?php

namespace Secupay\SecupayPayment\Model;

use Magento\Checkout\Model\ConfigProviderInterface;
use Secupay\SecupayPayment\Helper\Config;

/**
 * Class CheckoutConfigProvider
 * @package Secupay\SecupayPayment\Model
 */
class CheckoutConfigProvider implements ConfigProviderInterface
{
    /**
     * {@inheritdoc}
     */
    public function getConfig()
    {
        $config = Config::getConfigValue(Config::PAYMENT_CREDIT_CARD_ACTIVE);

        return [
            'payment' => [
                'secupay' => [
                    'getBanner' => $config,
                    'isCustomerProtectionEnabled' => $config
                ]
            ]
        ];
    }
}