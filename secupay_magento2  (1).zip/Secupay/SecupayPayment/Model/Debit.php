<?php

namespace Secupay\SecupayPayment\Model;

use Secupay\SecupayPayment\Helper\Config;

/**
 * Class Debit
 * @package Secupay\SecupayPayment\Model
 */
class Debit extends Communication
{
    const PAYMENT_CODE = 'secupay_debit';

    /**
     * @return bool
     */
    public function canUseCheckout()
    {
        // Check if the delivery address can be different from the billing address
        $differentDelivery = Config::getConfigValue(Config::PAYMENT_DEBIT_DIFFERENT_DELIVERY_ADDRESS_ALLOWED);
        if ($this->getDifferentShippingAddress() && $differentDelivery == 1) {
            return false;
        }

        $currency = $this->getCurrencyCode();
        if (empty($currency)) {
            return false;
        }

        // Check if currency is supported by the contract
        $contractCurrencies = Config::getConfigValue(Config::PAYMENT_DEBIT_CURRENCIES_SUPPORTED);
        if (strpos($contractCurrencies, $currency) === false) {
            return false;
        }

        // Check if currency is activated by the merchant
        $activatedCurrencies = Config::getConfigValue(Config::PAYMENT_DEBIT_CURRENCIES_ACTIVE);
        if (strpos($activatedCurrencies, $currency) === false) {
            return false;
        }

        // Load min and max amount
        $this->_minAmount = Config::getConfigValue(Config::PAYMENT_DEBIT_MIN_ORDER_TOTAL);
        $this->_maxAmount = Config::getConfigValue(Config::PAYMENT_DEBIT_MAX_ORDER_TOTAL);

        return parent::canUseCheckout();
    }
}
