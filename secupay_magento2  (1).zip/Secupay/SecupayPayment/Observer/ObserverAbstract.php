<?php

namespace Secupay\SecupayPayment\Observer;

use Psr\Log\LoggerInterface;
use Secupay\SecupayPayment\Helper\SecuconnectFactory;
use Secupay\SecupayPayment\Model\DbConnector;
use Magento\Framework\Event\Observer;

/**
 * Class ObserverAbstract
 * @package Secupay\SecupayPayment\Observer
 */
abstract class ObserverAbstract implements ObserverInterface
{
    /**
     * @var DbConnector
     */
    protected $dbConnector;

    /**
     * @var LoggerInterface
     */
    protected $logger;

    /**
     * @var SecuconnectFactory
     */
    protected $clientFactory;

    /**
     * ObserverAbstract constructor.
     * @param LoggerInterface $logger
     * @param DbConnector $dbConnector
     * @param SecuconnectFactory $clientFactory
     */
    public function __construct(LoggerInterface $logger, DbConnector $dbConnector, SecuconnectFactory $clientFactory)
    {
        $this->logger = $logger;
        $this->dbConnector = $dbConnector;
        $this->clientFactory = $clientFactory;
    }

    /**
     * @param Observer $observer
     * @return bool
     */
    abstract public function execute(Observer $observer);
}