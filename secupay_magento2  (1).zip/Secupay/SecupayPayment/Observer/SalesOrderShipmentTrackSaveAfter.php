<?php

namespace Secupay\SecupayPayment\Observer;

use Magento\Sales\Api\Data\ShipmentTrackInterface;
use Secuconnect\Client;
use Magento\Framework\Event\Observer;

/**
 * Class SalesOrderShipmentTrackSaveAfter
 * @package Secupay\SecupayPayment\Observer
 */
class SalesOrderShipmentTrackSaveAfter extends ObserverAbstract
{

    /**
     * @param Observer $observer
     *
     * @return bool
     */
    public function execute(Observer $observer)
    {
        /**
         * @var \Magento\Sales\Model\Order\Shipment\Track $track
         */
        $track = $observer->getEvent()->getTrack();
        $trackid = $track->getNumber();
        $carrier = $track->getTitle();
        $order = $track->getShipment()->getOrder();
        $order_id = $order->getIncrementId();
        $this->dbConnector->saveTrackingInformation('track', $order_id, $trackid, $carrier);


        $data = $this->dbConnector->searchOrder($order_id, ['hash', 'payment_type']);

        if (empty($data['hash'])) {
            return false;
        }

        // Add shipping information
        $tracking = null;
        if ($track instanceof ShipmentTrackInterface) {
            $tracking = [
                'carrier' => $track->getTitle(),
                'tracking_id' => $track->getNumber()
            ];
        }

        // Build request
        $capture_data = [
            'payment_id' => $data['hash'],
            'payment_method' => $data['payment_type'],
            'invoice_number' => $this->dbConnector->searchOrder($order_id, 'searchcode'),
            'tracking' => $tracking,
        ];


        // Send request
        $res = $this->getSecuconnectClient()->capture($capture_data);
        if ($res) {
            $this->dbConnector->saveTrackingInformation('track', $order_id, $trackid, $carrier);
        }

        return $res;
    }

    /**
     * @return Client
     */
    private function getSecuconnectClient()
    {
        return $this->clientFactory->getSecuconnectClient();
    }
}
