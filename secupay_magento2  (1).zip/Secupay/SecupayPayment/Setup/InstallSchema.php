<?php

namespace Secupay\SecupayPayment\Setup;

use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;

/**
 * Class InstallSchema
 * @package Secupay\SecupayPayment\Setup
 */
class InstallSchema implements InstallSchemaInterface
{
    /**
     * @param SchemaSetupInterface $setup
     * @param ModuleContextInterface $context
     */
    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $installer = $setup;
        $installer->startSetup();
        $installer->run("
            DELETE FROM `" . $installer->getTable('core_config_data') . "` WHERE path LIKE 'payment/secupay%' OR path LIKE 'secupay/secupay%' ;
            ");
        $installer->run("
            CREATE TABLE IF NOT EXISTS `" . $installer->getTable('secupay_transactions') . "` (
              `secupay_transaction_id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
              `req_data` TEXT,
              `ret_data` TEXT,
              `payment_type` VARCHAR(255) DEFAULT NULL,
              `hash` VARCHAR(255) DEFAULT NULL,
              `unique_id` VARCHAR(255) DEFAULT NULL,
              `ordernr` VARCHAR(11) DEFAULT NULL,
              `trans_id` INT(10) UNSIGNED DEFAULT 0,
              `msg` VARCHAR(255) DEFAULT NULL,
              `rank` INT(10) DEFAULT NULL,
              `status` VARCHAR(20) DEFAULT NULL,
              `amount` VARCHAR(255) DEFAULT NULL,
              `updated` DATETIME DEFAULT NULL,
              `created` DATETIME DEFAULT NULL,
              `timestamp` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
              `v_status` VARCHAR(20) DEFAULT NULL,
              `v_send` VARCHAR(20) DEFAULT NULL,
              `track_number` VARCHAR(255) DEFAULT NULL,
              `track_send` VARCHAR(1) DEFAULT NULL,
              `carrier_code` VARCHAR(32) DEFAULT NULL,
              `searchcode` VARCHAR(255) DEFAULT NULL,
              PRIMARY KEY (`secupay_transaction_id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8;
            ");
        $installer->run("
                CREATE TABLE IF NOT EXISTS `" . $installer->getTable('secupay_transaction_tracking') . "` (
                  `hash` VARCHAR(255) DEFAULT NULL,
                  `tracking_code` VARCHAR(255) DEFAULT NULL,
                  `carrier_code` VARCHAR(255) DEFAULT NULL,
                  `v_send` INT(10) DEFAULT NULL,
                  `timestamp` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8;
            ");

        $this->createSecupayCustomerTable($installer);

        $installer->endSetup();
    }

    /**
     * Creates the table 'secupay_customer'
     *
     * @param SchemaSetupInterface $installer
     */
    private function createSecupayCustomerTable(SchemaSetupInterface $installer)
    {
        $sql = 'CREATE TABLE IF NOT EXISTS `' . $installer->getTable('secupay_customer') . '` (
                  `entity_id`           INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
                  `customer_id`         VARCHAR(255)     NOT NULL,
                  `secupay_customer_id` VARCHAR(255)              DEFAULT NULL,
                  `created`             TIMESTAMP        NOT NULL DEFAULT CURRENT_TIMESTAMP,
                  `updated`             TIMESTAMP        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                  PRIMARY KEY (`entity_id`),
                  UNIQUE KEY `key_customer_id` (`customer_id`) USING HASH
                )
                  ENGINE = InnoDB
                  DEFAULT CHARSET = utf8;';
        $installer->run($sql);
    }
}