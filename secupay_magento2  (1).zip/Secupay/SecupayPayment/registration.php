<?php

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Secupay_SecupayPayment',
    __DIR__
);

require_once __DIR__ . '/Helper/secuconnect-sdk/vendor/autoload.php';

error_reporting(E_ALL & ~E_NOTICE);