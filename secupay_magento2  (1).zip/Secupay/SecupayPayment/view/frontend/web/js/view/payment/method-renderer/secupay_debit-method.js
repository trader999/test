define(
    [
        'jquery',
        'Magento_Checkout/js/view/payment/default',
        'mage/url',
        'Magento_Checkout/js/action/place-order'
    ],
    function ($, Component, url, placeOrderAction) {
        'use strict';
        return Component.extend({
            defaults: {
                template: 'Secupay_SecupayPayment/payment/secupay_debit',
                redirectAfterPlaceOrder: false
            },
            afterPlaceOrder: function (data, event) {
                window.location.replace(url.build('secuconnect/payment/redirect/'));
            }
        });
    }
);
