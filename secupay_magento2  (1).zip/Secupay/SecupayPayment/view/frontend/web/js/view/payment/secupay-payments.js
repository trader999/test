define(
    [
        'uiComponent',
        'Magento_Checkout/js/model/payment/renderer-list'
    ],
    function (Component, rendererList) {
        'use strict';
        rendererList.push(
            {
                type: 'secupay_creditcard',
                component: 'Secupay_SecupayPayment/js/view/payment/method-renderer/secupay_creditcard-method'
            },
            {
                type: 'secupay_debit',
                component: 'Secupay_SecupayPayment/js/view/payment/method-renderer/secupay_debit-method'
            },
            {
                type: 'secupay_invoice',
                component: 'Secupay_SecupayPayment/js/view/payment/method-renderer/secupay_invoice-method'
            },
            {
                type: 'secupay_prepay',
                component: 'Secupay_SecupayPayment/js/view/payment/method-renderer/secupay_prepay-method'
            }/**,
            {
                type: 'secupay_sofort',
                component: 'Secupay_SecupayPayment/js/view/payment/method-renderer/secupay_sofort-method'
            },
            {
                type: 'secupay_paypal',
                component: 'Secupay_SecupayPayment/js/view/payment/method-renderer/secupay_paypal-method'
            }*/
        );
        return Component.extend({});
    }
);
