Install

Copy in Magento 2 Root\app\code


edit Magento 2 Root\app\etc\config.php
and add
'Secupay_SecupayPayment' => 1,