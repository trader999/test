<?php

/*
 * IGNORE (FOR LATER)
 */

namespace Secupay\SecupayPayment\Block\Form;

use Magento\Payment\Block\Form;

/**
 * Class Creditcard
 * @package Secupay\SecupayPayment\Block\Form
 */
class Creditcard extends Form
{
    /**
     * Creditcard template
     *
     * @var string
     */
    protected $_template = 'Secupay_SecupayPayment::form/creditcard.phtml';
}
