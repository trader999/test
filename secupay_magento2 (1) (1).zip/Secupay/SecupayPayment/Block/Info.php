<?php

namespace Secupay\SecupayPayment\Block;

use Magento\Framework\App\ObjectManager;
use Magento\Sales\Api\Data\OrderPaymentInterface;
use Magento\Sales\Model\Order;
use Secupay\SecupayPayment\Helper\TransactionHelper;
use Secupay\SecupayPayment\Helper\Config;
use Secupay\SecupayPayment\Helper\Lang;

/**
 * Class Info
 * @package Secupay\SecupayPayment\Block
 */
class Info extends \Magento\Payment\Block\Info
{
    const TEMPLATE = 'info/info.phtml';
    const TEMPLATE_PDF = 'info/pdf/info.phtml';

    protected function _construct()
    {
        parent::_construct();
        $this->setTemplate(self::TEMPLATE);
    }

    /**
     * @return string
     */
    public function toPdf()
    {
        return $this->setTemplate(self::TEMPLATE_PDF)->toHtml();
    }

    /**
     * @return array
     */
    public function getSpecificInformation()
    {
        $payment = ObjectManager::getInstance()->get(TransactionHelper::class)->getTransactionData($this->getOrderId());

        // Remove unneeded data
        if (isset($payment['transfer_account']['accountnumber'])) {
            unset($payment['transfer_account']['accountnumber']);
        }
        if (isset($payment['transfer_account']['bankcode'])) {
            unset($payment['transfer_account']['bankcode']);
        }

        // Add data
        if (in_array($this->getPaymentType(), ['secupay_invoice', 'secupay_prepay'])) {
            $payment['transfer_account']['transfer_purpose'] = $payment['transfer_purpose'];
        } else {
            $payment['transfer_account']['trans_id'] = $payment['trans_id'];
        }

        if ($this->getPaymentType() == 'secupay_invoice' && Config::getConfigValue(
                Config::PAYMENT_INVOICE_SHOW_DUE_DATE
            ) && $this->getOrder()->hasInvoices()
        ) {
            $payment['transfer_account']['lang_duedate_info_before'] = (int)Config::getConfigValue(
                    Config::PAYMENT_INVOICE_DUE_DATE
                ) . __(Lang::DUE_DATE_INFO_AFTER);
        }

        return $payment['transfer_account'];
    }

    /**
     * @return string|false
     */
    private function getOrderId()
    {
        return $this->getOrder()->getIncrementId();
    }

    /**
     * @return OrderPaymentInterface
     */
    private function getOrderPayment()
    {
        return $this->getOrder()->getPayment();
    }

    /**
     * @return string
     */
    private function getPaymentType()
    {
        return $this->getOrderPayment()->getMethod();
    }

    /**
     * @return Order
     */
    private function getOrder()
    {
        return $this->getInfo()->getOrder();
    }
}
