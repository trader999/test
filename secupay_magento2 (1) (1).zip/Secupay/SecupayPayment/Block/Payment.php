<?php

namespace Secupay\SecupayPayment\Block;

use Magento\Framework\App\ObjectManager;
use Magento\Framework\View\Element\Template;

/**
 * Class Payment
 * @package Secupay\SecupayPayment\Block
 */
class Payment extends Template
{
    /**
     * Payment constructor.
     * @param Template\Context $context
     */
    public function __construct(Template\Context $context)
    {
        parent::__construct($context);
    }

    /**
     * @return string
     */
    public function showPaymentUrl()
    {
        $paymentUrl = ObjectManager::getInstance()->get('Magento\Customer\Model\Session')->getPaymentUrl();
        $this->_logger->notice(__METHOD__ . ' -> PaymentUrl: ' . $paymentUrl);
        return (string)$paymentUrl;
    }
}
