<?php

namespace Secupay\SecupayPayment\Controller\Payment;

use Secupay\SecupayPayment\Controller\ProcessController;
use Secupay\SecupayPayment\Helper\Lang;
use Magento\Checkout\Model\Cart;

/**
 * Handle errors during the payment checkout process
 * @package Secupay\SecupayPayment\Controller\Payment
 */
class Failure extends ProcessController
{
    public function execute()
    {
        // Load the order
        $order = $this->getOrder();
        $orderId = $order->getIncrementId();

        // Cancel the order
        $order->cancel();

        // Update the payment status table
        $this->db->savePaymentInformation('failure', null, null, null, $orderId, null, null, null, null, 'failure');

        // Leave a comment into the order status history
        $comment = sprintf(__(Lang::ABORT), date('d.m.Y H:i:s'));
        $order->addStatusHistoryComment($comment);
        $order->save();

        // Load the ordered items into a new basket
        $cart = $this->objectManager->get(Cart::class);
        foreach ($order->getItemsCollection() as $item) {
            try {
                $cart->addOrderItem($item);
            } catch (\Exception $e) {
                $this->logger->warning($e);
            }
        }

        $cart->save();

        // Redirect the user to the new created cart
        $this->_redirect('checkout/cart/');
    }
}