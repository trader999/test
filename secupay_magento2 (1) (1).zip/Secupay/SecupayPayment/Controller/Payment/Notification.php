<?php

namespace Secupay\SecupayPayment\Controller\Payment;

use Magento\Sales\Model\Order;
use Magento\Sales\Model\Order\Payment\Transaction;
use Secupay\SecupayPayment\Controller\ProcessController;
use Secupay\SecupayPayment\Helper\Config;

/**
 * Class Notification
 * @package Secupay\SecupayPayment\Controller\Payment
 */
class Notification extends ProcessController
{
    public function execute()
    {
        $client_ip = $this->_objectManager->get('Magento\Framework\HTTP\PhpEnvironment\RemoteAddress')->getRemoteAddress();
        $client_ip = str_replace("127.0.0.1", "", $client_ip);
        $client_ip = str_replace(" ", "", $client_ip);
        $client_ip = str_replace(",", "", $client_ip);
        if (ip2long($client_ip) > ip2long(self::high_ip) && ip2long($client_ip) < ip2long(self::low_ip)) {
            $this->logger->debug(__METHOD__ . ' -> Notify action: request+invalid: ' . json_encode(func_get_args()));
            $this->getResponse()->setBody('ack=Disapproved&error=request+invalid&' . http_build_query($_POST));

            return;
        }
        $this->requestOrderId = $this->getRequest()->getParam('orderId');
        if (!is_null($this->getRequest()->getParam('orderId')) && $this->db->searchOrder($this->requestOrderId,
                'unique_id') == $this->getRequest()->getParam('uid')
        ) {
            $this->logger->debug(__METHOD__ . ' -> Notify action: request+invalid: ' . json_encode(func_get_args()));
            $this->requestOrderId = $this->getRequest()->getParam('orderId');
            $this->logger->debug(__METHOD__ . ' -> orderId: ' . json_encode($this->requestOrderId));

            /**
             * @var \Secupay\SecupayPayment\Model\Debit $communication
             */
            // FIXME get the right payment type
            $communication = $this->_objectManager->get(
                'Secupay\SecupayPayment\Model\Debit'
            );
            $statusData = $communication->getStatusData(file_get_contents('php://input'));

            $this->handleMagentoStatusUpdate($statusData);
            if ($statusData['status'] === 'accepted') {

                if ($this->_getCreateInvoiceOption()) {
                    $this->_generateInvoice($this->getOrder());
                }

                $order = $this->getOrder();
                $this->logger->debug(__METHOD__ . ' -> $this->$order->getId(): ' . json_encode($order->getIncrementId()));
                $this->logger->debug(__METHOD__ . ' -> trans_id: ' . json_encode($statusData['trans_id']));
                $payment = $order->getPayment();
                $payment->setTransactionId($statusData['trans_id']);
                $payment->setParentTransactionId($payment->getTransactionId());
                //$payment->setLastTransId($statusData['trans_id']);
                $payment->setAmountPaid($statusData['amount'] / 100);
                $payment->setIsTransactionClosed(true);
                $payment->addTransaction(Transaction::TYPE_CAPTURE, null, true);

                $message = __('The authorized amount is %1.', ($statusData['amount'] / 100));
                //get the object of builder class
                $trans = $this->_objectManager->get('Magento\Sales\Model\Order\Payment\Transaction\BuilderInterface');
                $transaction = $trans->setPayment($payment)
                    ->setOrder($order)
                    ->setTransactionId($statusData['trans_id'])
                    ->setAdditionalInformation(
                        [Transaction::RAW_DETAILS => (array)$statusData]
                    )
                    ->setFailSafe(true)
                    //build method creates the transaction and returns the object
                    ->build(Transaction::TYPE_CAPTURE);

                $payment->addTransactionCommentsToOrder(
                    $transaction,
                    $message
                );

                $payment->save();
                $order->save();
            }
            $this->getResponse()->setBody('ack=Approved&' . http_build_query($_POST));
        } else {
            $this->getResponse()->setBody('ack=Disapproved&error=no+matching+order+found+for+id&' . http_build_query($_POST));

            return;

        }
        // TODO setzten der Zahlung
    }

    /**
     * @param array $statusData
     */
    private function handleMagentoStatusUpdate(array $statusData)
    {
        $this->db->savePaymentInformation('push', null, null, null, $this->requestOrderId, null, $statusData['trans_id'],
            null, null, $statusData['status']);
        $status = $this->getMagentoStatus($statusData['status']);
        $comment = $this->_getHistoryComment($statusData);
        $state = $this->_objectManager->get('Magento\Sales\Model\ResourceModel\Status\Collection')
            ->addAttributeToFilter("state_table.status", $status)
            ->getFirstItem()
            ->getData('state');
        $order = $this->getOrder();
        $order->setState($state);
        $order->setStatus($status);

        $order->addStatusHistoryComment($comment, false);
        $order->save();

    }

    /**
     * @param $status
     *
     * @return int
     */
    private function getMagentoStatus($status)
    {
        switch ($status) {
            case 'waiting':
            case 'denied':
            case 'canceled':
            case 'accepted':
            case 'issue':
            case 'void':
                $new_status = $status;
                break;
            case 'authorized':
                if ($this->getOrder()->getPayment()->getMethod() == 'secupay_prepay') {
                    $new_status = 'waiting';
                } else {
                    $new_status = 'authorized';
                }
                break;
            default:
                return 0;

        }

        return Config::getConfigValue('secupay/secupay/order_status_' . $new_status);
    }

    /**
     * @param array $statusData
     *
     * @return \Magento\Framework\Phrase|mixed|string
     */
    private function _getHistoryComment(array $statusData)
    {
        $comment = 'Status message not defined.';
        $commentKey = 'received_' . $statusData['status'];

        if (array_key_exists($commentKey, $this->_commentMessages)) {
            $comment = __($this->_commentMessages[$commentKey]);
        }

        $comment = str_replace('[[date]]', date('d.m.Y H:i:s'), $comment);
        $comment = str_replace(
            '[[transaction_id]]',
            array_key_exists('transaction_id', $statusData) ? $statusData['transaction_id'] : 'Not available',
            $comment
        );

        $comment = str_replace(
            '[[refunded_amount]]',
            array_key_exists('amount_refunded', $statusData) ? $statusData['amount_refunded'] : 'Not available',
            $comment
        );

        return $comment;
    }

    /**
     * @return bool
     */
    private function _getCreateInvoiceOption()
    {
        return (bool)Config::getConfigValue(Config::ORDER_CREATE_INVOICE);
    }

    /**
     * @param Order $order
     */
    private function _generateInvoice(Order $order)
    {
        if ($order->canInvoice()) {
            $invoice = $order->prepareInvoice();
            $invoice->register();
            $invoice->pay()->save();
            $order->save();

            if (Config::getConfigValue(Config::ORDER_SEND_MAIL)) {
                $invoiceSender = $this->_objectManager->get('Magento\Sales\Model\Order\Email\Sender\InvoiceSender');
                $invoiceSender->send($invoice);
            }
        }
    }
}
