<?php

namespace Secupay\SecupayPayment\Controller\Payment;

use Magento\Checkout\Model\Session;
use Magento\Sales\Model\Order;
use Secupay\SecupayPayment\Controller\ProcessController;
use Secupay\SecupayPayment\Helper\Lang;

/**
 * Class Success
 * @package Secupay\SecupayPayment\Controller\Payment
 */
class Success extends ProcessController
{
    public function execute()
    {
        // Load the order
        $order = $this->getOrder();

        // Session timeout?
        if (empty($order->getQuoteId())) {
            // Load order by UID
            $uid = $this->db->searchOrder($this->requestOrderId, 'unique_id', true);
            $this->logger->notice(__METHOD__ . ' -> orderId: ' . json_encode($this->requestOrderId) . ' uid:' . json_encode($uid));

            if (empty($uid)) {
                // No UID -> redirect to the cart page
                $this->_redirect('checkout/cart/');
                return;
            }

            $order = $this->objectManager->get(Order::class)->loadByIncrementId($this->requestOrderId);
        } else {
            $this->objectManager->get(Session::class)
                ->setLastOrderId($order->getId())
                ->setLastSuccessQuoteId($order->getQuoteId())
                ->setLastRealOrderId($order->getIncrementId());
        }

        // Leave a comment into the order status history
        $transId = $order->getPayment()->getAdditionalInformation('secupay_transaction_id');
        $comment = sprintf(__(Lang::TRANSACTION_PENDING), $transId, date('d.m.Y H:i:s'));
        $order->addStatusHistoryComment($comment);
        $order->save();

        // Update the payment status table
        $this->db->savePaymentInformation('success', null, null, null, $order->getIncrementId(), null, null, null, null,
            'success');

        // Redirect to the success page
        $this->_redirect('checkout/onepage/success/');
    }
}