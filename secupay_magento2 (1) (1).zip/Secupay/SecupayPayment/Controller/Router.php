<?php

namespace Secupay\SecupayPayment\Controller;

use Magento\Framework\App\RequestInterface;
use Magento\Framework\App\RouterInterface;
use Magento\Framework\App\ActionFactory;

/**
 * Class Router
 * @package Secupay\SecupayPayment\Controller
 */
class Router implements RouterInterface
{
    /**
     * @var ActionFactory
     */
    protected $actionFactory;
    /**
     * Response
     *
     * @var RouterInterface
     */
    protected $_response;

    /**
     * @param ActionFactory $actionFactory
     * @param RouterInterface $response
     */
    public function __construct(
        ActionFactory $actionFactory,
        RouterInterface $response
    ) {
        $this->actionFactory = $actionFactory;
        $this->_response = $response;
    }

    /**
     * Validate and Match
     *
     * @param RequestInterface $request
     *
     * @return bool
     */
    public function match(RequestInterface $request)
    {

        $identifier = trim($request->getPathInfo(), '/');
        if (strpos($identifier, 'exampletocms') !== false) {

            $request->setModuleName('cms')->setControllerName('page')->setActionName('view')->setParam('page_id', 5);
        } else {
            if (strpos($identifier, 'push') !== false) {
                $request->setModuleName('secupaypayment')->setControllerName('push')->setActionName('push');
            } else {
                return false;
            }
        }

        /*
         * We have match and now we will forward action
         */

        return $this->actionFactory->create(
            'Magento\Framework\App\Action\Forward',
            ['request' => $request] // FIXME remove this parameter?
        );
    }
}