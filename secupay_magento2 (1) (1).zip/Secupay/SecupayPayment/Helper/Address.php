<?php

namespace Secupay\SecupayPayment\Helper;

use Magento\Customer\Api\Data\AddressInterface;

/**
 * Class Address
 * @package Secupay\SecupayPayment\Helper
 */
class Address
{
    const ID = 'id';
    const CUSTOMER_ID = 'customerId';
    const REGION = 'region';
    const REGION_ID = 'region_id';
    const COUNTRY_CODE = 'countryCode';
    const STREET = 'street';
    const HOUSE_NUMBER = '';
    const COMPANY = 'company';
    const TELEPHONE = 'telephone';
    const FAX = 'fax';
    const POSTAL_CODE = 'postalCode';
    const CITY = 'city';
    const FIRSTNAME = 'firstname';
    const LASTNAME = 'lastname';
    const NAME = 'name';
    const PREFIX = 'prefix';
    const SUFFIX = 'suffix';
    const VAT_ID = 'vat_id';

    const DEFAULT_BILLING = 'default_billing';
    const DEFAULT_SHIPPING = 'default_shipping';

    /**
     * Convert Magento address to array for json encode
     *
     * @param AddressInterface $address
     *
     * @return array
     */
    public function convertToArray(AddressInterface $address)
    {
        $data = [
            self::FIRSTNAME => $address->getFirstname(),
            self::LASTNAME => $address->getLastname(),
            self::NAME => trim(trim($address->getFirstname() . ' ' . $address->getMiddlename()) . ' ' . $address->getLastname()),

            self::STREET => $address->getStreet(),

            self::POSTAL_CODE => $address->getPostcode(),
            self::CITY => $address->getCity(),
            self::COUNTRY_CODE => $address->getCountryId(),

            self::COMPANY => $address->getCompany(),
            self::TELEPHONE => null,
        ];

        if ($address->getTelephone()) {
            $data[AddressInterface::TELEPHONE] = $address->getTelephone();
        }

        if ($address->getRegion()) {
            $data[AddressInterface::REGION] = $address->getRegion()->getRegion();

            if ($address->getRegion()->getRegionId()) {
                $data[AddressInterface::REGION_ID] = $address->getRegion()->getRegionId();
                $data['region_code'] = $address->getRegion()->getRegionCode();
            }
        }

        return $data;
    }
}