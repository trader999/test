<?php

namespace Secupay\SecupayPayment\Helper;

use Magento\Framework\App\Config\ConfigResource\ConfigInterface;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\App\ObjectManager;
use Magento\Framework\Encryption\EncryptorInterface;
use Magento\Store\Model\ScopeInterface;

/**
 * Class Config
 * @package Secupay\SecupayPayment\Helper
 */
class Config
{
    const PAYMENT_INVOICE_SHOW_DUE_DATE = 'payment/secupay_invoice/showduedate';
    const PAYMENT_INVOICE_DUE_DATE = 'payment/secupay_invoice/duedate';
    const PAYMENT_INVOICE_SEND_INVOICE_NUMBER = 'payment/secupay/send_invoice_number_auto';
    const ORDER_CREATE_INVOICE = 'payment/secupay/invoice_after_order';
    const ORDER_SEND_MAIL = 'payment/secupay/send_mail';
    const ORDER_SEND_ORDER_CONFIRMATION = 'payment/secupay/send_order_confirmation';
    const DEMO_MODE = 'secupay/secuconnect/demomode';

    const PAYMENT_INVOICE_MIN_ORDER_TOTAL = 'payment/secupay_invoice/min_order_total';
    const PAYMENT_INVOICE_MAX_ORDER_TOTAL = 'payment/secupay_invoice/max_order_total';
    const PAYMENT_INVOICE_CURRENCIES_SUPPORTED = 'payment/secupay_invoice/specificcurrency';
    const PAYMENT_INVOICE_CURRENCIES_ACTIVE = 'payment/secupay_invoice/contractcurrency';
    const PAYMENT_INVOICE_DIFFERENT_DELIVERY_ADDRESS_ALLOWED = 'payment/secupay_invoice/differentdelivery';

    const PAYMENT_CREDIT_CARD_ACTIVE = 'payment/secupay_creditcard/active';
    const PAYMENT_CREDIT_CARD_MIN_ORDER_TOTAL = 'payment/secupay_creditcard/min_order_total';
    const PAYMENT_CREDIT_CARD_MAX_ORDER_TOTAL = 'payment/secupay_creditcard/max_order_total';
    const PAYMENT_CREDIT_CARD_CURRENCIES_SUPPORTED = 'payment/secupay_creditcard/specificcurrency';
    const PAYMENT_CREDIT_CARD_CURRENCIES_ACTIVE = 'payment/secupay_creditcard/contractcurrency';
    const PAYMENT_CREDIT_CARD_DIFFERENT_DELIVERY_ADDRESS_ALLOWED = 'payment/secupay_creditcard/differentdelivery';

    const PAYMENT_DEBIT_MIN_ORDER_TOTAL = 'payment/secupay_debit/min_order_total';
    const PAYMENT_DEBIT_MAX_ORDER_TOTAL = 'payment/secupay_debit/max_order_total';
    const PAYMENT_DEBIT_CURRENCIES_SUPPORTED = 'payment/secupay_debit/specificcurrency';
    const PAYMENT_DEBIT_CURRENCIES_ACTIVE = 'payment/secupay_debit/contractcurrency';
    const PAYMENT_DEBIT_DIFFERENT_DELIVERY_ADDRESS_ALLOWED = 'payment/secupay_debit/differentdelivery';

    const PAYMENT_PREPAY_MIN_ORDER_TOTAL = 'payment/secupay_prepay/min_order_total';
    const PAYMENT_PREPAY_MAX_ORDER_TOTAL = 'payment/secupay_prepay/max_order_total';
    const PAYMENT_PREPAY_CURRENCIES_SUPPORTED = 'payment/secupay_prepay/specificcurrency';
    const PAYMENT_PREPAY_CURRENCIES_ACTIVE = 'payment/secupay_prepay/contractcurrency';
    const PAYMENT_PREPAY_DIFFERENT_DELIVERY_ADDRESS_ALLOWED = 'payment/secupay_prepay/differentdelivery';

    const PAYMENT_PAYPAL_MIN_ORDER_TOTAL = 'payment/secupay_paypal/min_order_total';
    const PAYMENT_PAYPAL_MAX_ORDER_TOTAL = 'payment/secupay_paypal/max_order_total';
    const PAYMENT_PAYPAL_CURRENCIES_SUPPORTED = 'payment/secupay_paypal/specificcurrency';
    const PAYMENT_PAYPAL_CURRENCIES_ACTIVE = 'payment/secupay_paypal/contractcurrency';
    const PAYMENT_PAYPAL_DIFFERENT_DELIVERY_ADDRESS_ALLOWED = 'payment/secupay_paypal/differentdelivery';

    const PAYMENT_SOFORT_MIN_ORDER_TOTAL = 'payment/secupay_sofort/min_order_total';
    const PAYMENT_SOFORT_MAX_ORDER_TOTAL = 'payment/secupay_sofort/max_order_total';
    const PAYMENT_SOFORT_CURRENCIES_SUPPORTED = 'payment/secupay_sofort/specificcurrency';
    const PAYMENT_SOFORT_CURRENCIES_ACTIVE = 'payment/secupay_sofort/contractcurrency';
    const PAYMENT_SOFORT_DIFFERENT_DELIVERY_ADDRESS_ALLOWED = 'payment/secupay_sofort/differentdelivery';

    const SCOPE_STORE = ScopeInterface::SCOPE_STORE;
    const SCOPE_DEFAULT = ScopeConfigInterface::SCOPE_TYPE_DEFAULT;

    /**
     * @param string $path
     * @param string $scope
     *
     * @return mixed
     */
    public static function getConfigValue($path, $scope = self::SCOPE_DEFAULT)
    {
        return self::getReadConfig()->getValue($path, $scope);
    }

    /**
     * @param string $path
     * @param string $value
     * @param string $scope
     * @param int $scopeId
     * @return mixed
     */
    public static function saveConfigValue($path, $value, $scope = self::SCOPE_DEFAULT, $scopeId = 0)
    {
        return self::getSaveConfig()->saveConfig(
            $path,
            $value,
            $scope,
            $scopeId
        );
    }

    /**
     * @param string $value
     * @return string
     */
    public static function decryptValue($value)
    {
        return self::getEncrpyter()->decrypt($value);
    }

    /**
     * @return EncryptorInterface
     */
    private static function getEncrpyter()
    {
        return ObjectManager::getInstance()->get(EncryptorInterface::class);
    }

    /**
     * @return ConfigInterface
     */
    private static function getSaveConfig()
    {
        return ObjectManager::getInstance()->get(ConfigInterface::class);
    }

    /**
     * @return ScopeConfigInterface
     */
    private static function getReadConfig()
    {
        return ObjectManager::getInstance()->get(ScopeConfigInterface::class);
    }
}
