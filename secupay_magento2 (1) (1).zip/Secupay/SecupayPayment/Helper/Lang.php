<?php

namespace Secupay\SecupayPayment\Helper;

/**
 * Class Lang
 * @package Secupay\SecupayPayment\Helper
 */
class Lang
{
    const DUE_DATE_INFO_AFTER = 'lang_duedate_info_after';
    const ENABLED = 'Enabled';
    const DISABLED = 'Disabled';
    const REDIRECT = 'Redirection to Secupay AG. Transaction not finished. Transaction ID: %1$s. Time: %2$s';
    const TRANSACTION_PENDING = 'Transaction not finished. Transaction ID: %1$s. Time: %2$s';
    const RECEIVED_ACCEPTED = 'The payment has been accepted. Time: [[date]]';
    const ABORT = 'Payment aborted. Time: %1$s';
    const REFUNDED_COMPENSATION = 'Partial amount will be refunded - [[refunded_amount]]. Time: [[date]]';
    const REFUNDED_REFUNDED = 'Amount will be refunded. Time: [[date]]';
    const PAY_NOW = 'Please pay your order now';
}