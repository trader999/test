<?php

namespace Secupay\SecupayPayment\Helper;

use Magento\Framework\App\ObjectManager;
use Psr\Log\LoggerInterface;
use SecucardConnect\Client\StorageInterface;
use Secuconnect\Client;

/**
 * Class SecuconnectFactory
 * @package Secupay\SecupayPayment\Helper
 */
class SecuconnectFactory
{
    /**
     * @var LoggerInterface
     */
    private $logger;

    /**
     * @var StorageInterface
     */
    private $storage;

    /**
     * SecuconnectFactory constructor.
     *
     * @param LoggerInterface $logger
     * @param StorageInterface $storage
     */
    public function __construct(LoggerInterface $logger, StorageInterface $storage)
    {
        $this->logger = $logger;
        $this->storage = $storage;
    }

    /**
     * @return \Secuconnect\Client
     */
    public function getSecuconnectClient()
    {
        static $client = null;

        if ($client === null) {
            $client = new Client($this->getSDkConfig(), $this->logger, $this->storage);
        }

        return $client;
    }

    /**
     * @return array
     */
    private function getSDkConfig()
    {
        $config = [];

        foreach (array_keys(Client::CONFIG) as $name) {
            $config[$name] = Config::getConfigValue(
                'secupay/secuconnect/' . $name
            );
        }

        $config['client_secret'] = Config::decryptValue($config['client_secret']);

        return $config;
    }

    /**
     * Return the value for the HTTP Header 'User-Agent'
     *
     * @return string
     */
    private function getApiClientString()
    {
        return '';
    }

    /**
     * Return the value for the HTTP header 'Accept-Language'
     *
     * @return string
     */
    private function getAcceptLanguage()
    {
        return (string)ObjectManager::getInstance()->get('Magento\Framework\Locale\Resolver')->getLocale();
    }
}