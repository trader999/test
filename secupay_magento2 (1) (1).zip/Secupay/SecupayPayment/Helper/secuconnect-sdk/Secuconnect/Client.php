<?php

namespace Secuconnect;

use Psr\Log\LoggerInterface;
use SecucardConnect\ApiClientConfiguration;
use SecucardConnect\Auth\ClientCredentials;
use SecucardConnect\Auth\GrantTypeInterface;
use SecucardConnect\Client\DummyStorage;
use SecucardConnect\Client\ProductService;
use SecucardConnect\Client\StorageInterface;
use SecucardConnect\Product\Common\Model\Address;
use SecucardConnect\Product\Common\Model\Contact;
use SecucardConnect\Product\Payment\Model\Basket;
use SecucardConnect\Product\Payment\Model\Customer;
use SecucardConnect\Product\Payment\Model\Experience;
use SecucardConnect\Product\Payment\Model\PaymentInstrument;
use SecucardConnect\Product\Payment\Model\SecupayCreditcard;
use SecucardConnect\Product\Payment\Model\SecupayDebit;
use SecucardConnect\Product\Payment\Model\SecupayInvoice;
use SecucardConnect\Product\Payment\Model\SecupayPrepay;
use SecucardConnect\Product\Payment\Model\Transaction;
use SecucardConnect\Product\Payment\Model\TransferAccount;
use SecucardConnect\SecucardConnect;
use Secuconnect\Exception\NotImplementedException;
use SecucardConnect\Client\QueryParams;
use SecucardConnect\Product\Payment\Model\RedirectUrl;

/**
 * Class Client
 * @package Secuconnect
 */
class Client
{

    const PAYMENT_METHOD_MAPPING = [
        'secupay_creditcard' => 'secupaycreditcards',
        'secupay_debit' => 'secupaydebits',
        'secupay_invoice' => 'secupayinvoices',
        'secupay_prepay' => 'secupayprepays',
    ];

    const PAYMENT_METHOD_CLASS_MAPPING = [
        'secupay_creditcard' => SecupayCreditcard::class,
        'secupay_debit' => SecupayDebit::class,
        'secupay_invoice' => SecupayInvoice::class,
        'secupay_prepay' => SecupayPrepay::class,
    ];

    const CONFIG = [
        'active' => null,
        'client_id' => null,
        'client_secret' => null,
        'demomode' => null,
        'debug' => null,
    ];

    /**
     * @var Transaction
     */
    public $pushed_transaction;

    /**
     * @var array
     */
    private $config = self::CONFIG;

    /**
     * API URL.
     *
     * @var string
     */
    private $url = 'https://connect.secucard.com';

    /**
     * Debug mode.
     *
     * @var bool
     */
    private $debug = false;

    /**
     * @var SecucardConnect
     */
    private $client;

    /**
     * The logger instance.
     *
     * @var LoggerInterface
     */
    private $logger;

    /**
     * @var StorageInterface
     */
    private $storage;

    /**
     * Client constructor.
     * @param array $config
     * @param LoggerInterface $logger
     * @param StorageInterface $storage
     */
    public function __construct(array $config, LoggerInterface $logger, StorageInterface $storage = null)
    {
        $this->setConfig($config);
        $this->setLogger($logger);
        $this->setStorage($storage);
        $this->log('debug', __METHOD__ . ' -> args: ' . json_encode($this->config['client_id']));
        $this->registerPaymentChangedEvent();
    }

    /**
     * Set the config params
     *
     * @param array $config
     *
     * @return self
     */
    private function setConfig(array $config)
    {
        // Filter input
        foreach ($config as $key => $value) {
            if (array_key_exists($key, self::CONFIG) && $value !== null && $value !== '') {
                $this->config[$key] = $value;
            }
        }

        // TODO use the secupay config to enable this
//        if (isset($this->config['debug'])) {
//            $this->debug = (bool)$this->config['debug'];
//        }

        return $this;
    }

    /**
     * Sets a logger.
     *
     * @param LoggerInterface $logger
     *
     * @return self
     */
    public function setLogger(LoggerInterface $logger)
    {
        $this->logger = $logger;

        return $this;
    }

    /**
     * @param StorageInterface $storage
     *
     * @return self
     */
    public function setStorage(StorageInterface $storage = null)
    {
        $this->storage = $storage;

        return $this;
    }

    /**
     * @param string $level
     * @param string $message
     *
     * @return self
     */
    private function log($level, $message)
    {
        // Skip logging "debug" messages if not wanted
        if ($level == 'debug' && !$this->config['debug']) {
            return $this;
        }

        if (method_exists($this->logger, $level)) {
            $this->logger->$level($message);
        }

        return $this;
    }

    /**
     * Register function to handle new/changed objects
     */
    private function registerPaymentChangedEvent()
    {
        foreach (array_keys(self::PAYMENT_METHOD_MAPPING) as $paymentMethod) {
            /**
             * @var \SecucardConnect\Product\Payment\SecupayDebitsService $service
             */
            $service = $this->getPaymentService($this->mapServiceName($paymentMethod));

            $service->onStatusChange([$this, 'getTransactionByPaymentChangeEvent']);
        }
    }

    /**
     * @param $serviceName
     *
     * @return ProductService
     */
    private function getPaymentService($serviceName)
    {
        return $this->getSecucardConnect()->payment->{$serviceName};
    }

    /**
     * @return SecucardConnect
     */
    private function getSecucardConnect()
    {
        if (!$this->client instanceof SecucardConnect) {
            $this->client = new SecucardConnect(
                $this->getConfig(),
                $this->getLogger(),
                $this->getStorage(),
                $this->getStorage(),
                $this->getCredentials()
            );
        }

        return $this->client;
    }

    /**
     * @return ApiClientConfiguration
     */
    private function getConfig()
    {
        $config = new ApiClientConfiguration();

        if (!empty($this->url)) {
            $config->setBaseUrl($this->url);
        }

        if (!empty($this->debug)) {
            $config->setDebug($this->debug);
        }

//        $config->setApiClient();
//        $config->setAcceptLanguage();

        return $config;
    }

    /**
     * @return LoggerInterface
     */
    private function getLogger()
    {
        return $this->logger;
    }

    /**
     * @return StorageInterface
     */
    private function getStorage()
    {
        if (!$this->storage instanceof StorageInterface) {
            $this->storage = new DummyStorage();
            $this->log('error', __METHOD__ . ' -> DummyStorage created');
        }

        return $this->storage;
    }

    /**
     * @return GrantTypeInterface
     */
    private function getCredentials()
    {
        return new ClientCredentials($this->config['client_id'], $this->config['client_secret']);
    }

    /**
     * Convert the payment method to the sdk service name
     *
     * @param string $paymentMethod
     *
     * @throw NotImplementedException
     * @return string
     */
    private function mapServiceName($paymentMethod)
    {
        if (array_key_exists($paymentMethod, self::PAYMENT_METHOD_MAPPING)) {
            return self::PAYMENT_METHOD_MAPPING[$paymentMethod];
        }

        throw new NotImplementedException('payment method: ' . $paymentMethod . ' is not supported.');
    }

    /**
     * @inheritdoc
     */
    public function getCustomerId($secupayCustomerId = null, $customerData = [])
    {
        $this->log('debug', __METHOD__ . ' -> args: ' . json_encode(func_get_args()));

        // Return NULL if not data was given.
        if (empty($secupayCustomerId) && empty($customerData['email'])) {
            $this->log('debug', __METHOD__ . ' -> empty');

            return null;
        }

        // We have some data, lets start a search
        try {
            /**
             * @var \SecucardConnect\Product\Payment\CustomersService $service
             */
            $service = $this->getPaymentService('customers');

            // 1) Search by id
            if (!empty($secupayCustomerId)) {
                $customer = $service->get($secupayCustomerId);

                if (!empty($customer->id)) {
                    $this->log('debug', __METHOD__ . ' -> loaded customer by id: ' . json_encode($customer->id));

                    return $customer->id;
                }
            }

            // For the next steps we need a email address, so return NULL if we haven't one.
            if (empty($customerData['email'])) {
                $this->log('debug', __METHOD__ . ' -> empty email');

                return null;
            }

            // The firstname and lastname should not be empty, but to avoid errors set them to NULL in that case.
            $customer_firstname = empty($customerData['firstname']) ? null : $customerData['firstname'];
            $customer_lastname = empty($customerData['lastname']) ? null : $customerData['lastname'];

            // 2) Search by email, first_name, last_name
            $query = new QueryParams();
            $query->fields = ['id'];
            $query->count = 1;
            $query->query = 'email=' . $customerData['email']
                . ' AND forename=' . $customer_firstname
                . ' AND surname=' . $customer_lastname;
            $customers = $service->getList($query);

            if (!empty($customers->count)) {
                $customer = $customers->items[0];

                if (!empty($customer->id)) {
                    $this->log('debug', __METHOD__ . ' -> loaded customer by email: ' . json_encode($customer->id));

                    return $customer->id;
                }
            }

            // 3) Create a new one
            $contact = new Contact();
            $contact->email = $customerData['email'];
            $contact->forename = $customer_firstname;
            $contact->surname = $customer_lastname;

            $customer = new Customer();
            $customer->contact = $contact;

            $customer = $service->save($customer);
            $this->log('debug', __METHOD__ . ' -> created customer id: ' . json_encode($customer->id));

            return $customer->id;
        } catch (\Exception $e) {
            $this->log('debug', $e->getMessage());
        }

        $this->log('debug', __METHOD__ . ' -> null');

        return null;
    }

    /**
     * @param null $secupayCustomerId
     * @param array $customerData
     *
     * @return string|false The (secupay) customer id on success, FALSE otherwise
     */
    public function updateCustomer($secupayCustomerId = null, $customerData = [])
    {
        $this->log('debug', __METHOD__ . ' -> args: ' . json_encode(func_get_args()));

        // Return NULL if not data was given.
        if (empty($secupayCustomerId) && empty($customerData['email'])) {
            $this->log('debug', __METHOD__ . ' -> empty');

            return false;
        }

        try {
            /**
             * @var \SecucardConnect\Product\Payment\CustomersService $service
             */
            $service = $this->getPaymentService('customers');

            $contact = new Contact();
            $contact->gender = $customerData['gender'];
            $contact->title = $customerData['title'];
            $contact->forename = $customerData['firstname'];
            $contact->surname = $customerData['lastname'];
            $contact->companyname = $customerData['company'];
            $contact->dob = $customerData['dob'];
            $contact->email = $customerData['email'];
            $contact->phone = $customerData['telephone'];

            $address = new Address();
            $address->street = $customerData['street'];
            $address->city = $customerData['city'];
            $address->country = $customerData['country'];
            $address->postal_code = $customerData['zip'];
            $contact->address = $address;

            $customer = new Customer();
            $customer->id = $secupayCustomerId;
            $customer->merchant_customer_id = $customerData['merchant_customer_id'];
            $customer->contact = $contact;

            $customer = $service->save($customer);
            $this->log('debug', __METHOD__ . ' -> updated customer id: ' . json_encode($customer->id));

            return $customer->id;
        } catch (\Exception $e) {
            $this->log('debug', $e->getMessage());
        }

        $this->log('debug', __METHOD__ . ' -> null');

        return false;
    }

    /**
     * @see
     *
     * @inheritdoc
     */
    public function getPaymentMethods($reqParams = [])
    {
        $this->log('debug', __METHOD__ . ' -> args: ' . json_encode(func_get_args()));
        return [
            'creditcard',
            'debit',
            'invoice',
            'prepay',
        ];

        /**
         * @var \SecucardConnect\Product\Payment\ContractsService $service
         */
        $service = $this->getPaymentService('contracts');

        $res = $service->getPaymentMethods();

        if ($res) {
            // Successful
            return $res;
        }

        return [];
    }

    /**
     * @see
     *
     * @inheritdoc
     */
    public function getCurrencies($reqParams = [])
    {
        $this->log('debug', __METHOD__ . ' -> args: ' . json_encode(func_get_args()));
        return ['EUR'];
        $paymentMethod = $reqParams['payment_method'];

        /**
         * @var \SecucardConnect\Product\Payment\Service\PaymentService $service
         */
        $service = $this->getPaymentService($this->mapServiceName($paymentMethod));

        $res = $service->getCurrencies();

        if ($res) {
            // Successful
            return $res;
        }

        return [];
    }

    /**
     * @see
     *
     * @inheritdoc
     */
    public function cancel($reqParams = [])
    {
        $this->log('debug', __METHOD__ . ' -> args: ' . json_encode(func_get_args()));
        $paymentMethod = $reqParams['payment_method'];

        /**
         * @var \SecucardConnect\Product\Payment\Service\PaymentService $service
         */
        $service = $this->getPaymentService($this->mapServiceName($paymentMethod));

        if ($service->cancel($reqParams['hash'])) {
            // Successful
        }
    }

    /**
     * @inheritdoc
     */
    public function authorize($reqParams = [])
    {
        $this->log('debug', __METHOD__ . ' -> args: ' . json_encode(func_get_args()));
        $paymentMethod = $reqParams['payment_method'];

        /**
         * @var \SecucardConnect\Product\Payment\Service\PaymentService $service
         */
        $service = $this->getPaymentService($this->mapServiceName($paymentMethod));

        /**
         * @var Transaction $payment
         */
        $payment = $this->modelFactory($paymentMethod);
        $this->log('debug', __METHOD__ . ' -> $payment: ' . gettype($payment));
        $payment->amount = (int)$reqParams['amount'];
        $payment->currency = $reqParams['currency'];
        $payment->order_id = $reqParams['order_id'];
        $payment->purpose = $reqParams['purpose'];
        $payment->accrual = (bool)$reqParams['set_accrual'];
        $payment->payment_action = $reqParams['payment_action'];
        $payment->subscription = null;
        $payment->demo = $reqParams['demo'];
        $payment->customer = new Customer();
        $payment->customer->id = $reqParams['customer_id'];

        if (!empty($reqParams['recipient_id'])) {
            $payment->recipient = new Customer();
            $payment->recipient->id = $reqParams['recipient_id'];
        }

        // Set urls
        $payment->redirect_url = new RedirectUrl();
        $payment->redirect_url->url_success = $reqParams['url_success'];
        $payment->redirect_url->url_failure = $reqParams['url_failure'];
        $payment->redirect_url->url_push = $reqParams['url_push'];

        // set experience
        $payment->experience = new Experience();
        $payment->experience->positiv = $reqParams['positive'];
        $payment->experience->negativ = $reqParams['negative'];

        $payment->basket = [];
        foreach ($reqParams['basket'] as $item) {
            $basket = new Basket();
            $basket->article_number = isset($item['article_number']) ? $item['article_number'] : null;
            $basket->ean = isset($item['ean']) ? $item['ean'] : null;
            $basket->item_type = isset($item['item_type']) ? $item['item_type'] : null;
            $basket->model = isset($item['model']) ? $item['model'] : null;
            $basket->name = isset($item['name']) ? $item['name'] : null;
            $basket->price = isset($item['price']) ? (int)$item['price'] : null;
            $basket->quantity = isset($item['quantity']) ? (int)$item['quantity'] : null;
            $basket->tax = isset($item['tax']) ? (int)$item['tax'] : null;
            $basket->total = isset($item['total']) ? (int)$item['total'] : null;
            $payment->basket[] = $basket;
        }

        $this->log('debug', __METHOD__ . ' -> $payment: ' . json_encode($payment));

        try {
            $payment = $service->save($payment);
            $this->log('debug', __METHOD__ . ' -> #3');

            return [
                'id' => $payment->id,
                'iframe_url' => $payment->redirect_url->iframe_url,
            ];

        } catch (\Exception $e) {
            echo 'Error message: ' . $e->getMessage() . "\n";
        }

        return null;
    }

    /**
     * Create a new model object for the given payment method
     *
     * @param string $paymentMethod
     *
     * @throw NotImplementedException
     * @return object
     */
    private function modelFactory($paymentMethod)
    {
        if (array_key_exists($paymentMethod, self::PAYMENT_METHOD_CLASS_MAPPING)) {
            $class = self::PAYMENT_METHOD_CLASS_MAPPING[$paymentMethod];

            return new $class;
        }

        throw new NotImplementedException('payment method: ' . $paymentMethod . ' is not supported.');
    }

    /**
     * @inheritdoc
     */
    public function capture($reqParams = [])
    {
        $this->log('debug', __METHOD__ . ' -> args: ' . json_encode(func_get_args()));

        /**
         * @var \SecucardConnect\Product\Payment\Service\PaymentService $service
         */
        $service = $this->getPaymentService($this->mapServiceName($reqParams['payment_method']));

        if ($reqParams['payment_method'] == 'secupay_invoice') {
            // Start the "capture" call
            if (!$service->capture($reqParams['payment_id'])) {
                return false;
            }
        }

        // Add shipping information
        if($service->setShippingInformation(
            $reqParams['payment_id'],
            $reqParams['tracking']['carrier'],
            $reqParams['tracking']['tracking_id'],
            $reqParams['invoice_number']
        )) {
            return true;
        }

        return false;
    }

    /**
     * @see
     *
     * @inheritdoc
     */
    public function getCaptureDetails($reqParams = [])
    {
        return $this->getPaymentTransactionDetails($reqParams);
    }

    /**
     * Return the details for a payment transaction
     *
     * @param array $reqParams
     *
     * @return array|null
     */
    public function getPaymentTransactionDetails($reqParams = [])
    {
        $service = $this->getPaymentService(
            $this->mapServiceName($reqParams['payment_method'])
        );

        $transaction = $service->get($reqParams['hash_id']);

        $transactionData = [];
        if ($transaction instanceof Transaction) {
            $transactionData['status'] = $transaction->status; // f.e. "authorized"
            $transactionData['transaction_status'] = $transaction->transaction_status; // f.e. "25"
            $transactionData['amount_refunded'] = 0; // TODO currently not supported
            $transactionData['transaction_id'] = $transaction->id; // f.e. "ufgjjwdfmwph1468032"
            $transactionData['trans_id'] = $transaction->trans_id; // f.e. "7867851"

            if ($transaction->used_payment_instrument instanceof PaymentInstrument) {
                $transactionData['payment_instrument']['type'] = $transaction->used_payment_instrument->type; // "bank_account" or "credit_card"
                $transactionData['payment_instrument']['data'] = $transaction->used_payment_instrument->data;
                // data for type "bank_account": 'owner', 'iban', 'bic', 'bankname'
                // data for type "credit_card": 'owner', 'pan', 'expiration_date', 'issuer'
            }

            if ($transaction instanceof SecupayPrepay || $transaction instanceof SecupayInvoice) {
                $transactionData['transfer_account'] = [];
                $transactionData['transfer_purpose'] = $transaction->transfer_purpose; // f.e. "TA 7867851"

                if ($transaction->transfer_account instanceof TransferAccount) {
                    $transactionData['transfer_account']['account_owner'] = $transaction->transfer_account->account_owner; // f.e. "secupay AG"
                    $transactionData['transfer_account']['accountnumber'] = $transaction->transfer_account->accountnumber; // f.e. "1747013"
                    $transactionData['transfer_account']['iban'] = $transaction->transfer_account->iban; // f.e. "DE88300500000001747013"
                    $transactionData['transfer_account']['bic'] = $transaction->transfer_account->bic; // f.e. "WELADEDDXXX"
                    $transactionData['transfer_account']['bankcode'] = $transaction->transfer_account->bankcode; // f.e. "30050000"
                }
            }

            return $transactionData;
        }

        return null;
    }

    /**
     * @inheritdoc
     */
    public function refund($reqParams = [])
    {
        $this->log('debug', __METHOD__ . ' -> args: ' . json_encode(func_get_args()));
        $paymentMethod = $reqParams['payment_method'];
        $amount = !empty($reqParams['amount']) ? $reqParams['amount'] : 0;

        /**
         * @var \SecucardConnect\Product\Payment\Service\PaymentService $service
         */
        $service = $this->getPaymentService($this->mapServiceName($paymentMethod));

        if ($service->cancel($reqParams['hash'], null, $amount)) {
            // Successful
        }
    }

    /**
     * @inheritdoc
     */
    public function getRefundDetails($reqParams = [])
    {
        return $this->getPaymentTransactionDetails($reqParams);
    }

    /**
     * @deprecated for later...
     *
     * @inheritdoc
     */
    public function getServiceStatus($reqParams = [])
    {
        throw new NotImplementedException(__METHOD__);
    }

    /**
     * @param Transaction $obj
     */
    public function getTransactionByPaymentChangeEvent($obj)
    {
        $this->pushed_transaction = $obj;
    }

    /**
     * @param string $rawData
     */
    public function handlePaymentChangeEvent($rawData)
    {
        $this->getSecucardConnect()->handleEvent($rawData);
    }
}
