<?php

namespace Secuconnect;

/**
 * Interface ClientInterface
 * @package Secuconnect
 */
interface ClientInterface
{

    /**
     * Return data of the users profile
     *
     * @param $userAccessToken
     *
     * @return mixed
     */
    public function getCustomerId($userAccessToken);

    /**
     * Get the details of an existing payment transaction
     *
     * @param array $requestParameters
     *      requestParameters['hash_id'] - [String]
     *      requestParameters['payment_method'] - [String]
     *
     * @return ResponseParser
     */
    public function getOrderReferenceDetails($requestParameters = []);

    /**
     * @param array $requestParameters
     *
     * @return mixed
     */
    public function setOrderReferenceDetails($requestParameters = []);

    /**
     * @param array $requestParameters
     *
     * @return mixed
     */
    public function confirmOrderReference($requestParameters = []);

    /**
     * @param array $requestParameters
     *
     * @return mixed
     */
    public function cancelOrderReference($requestParameters = []);

    /**
     * @param array $requestParameters
     *
     * @return mixed
     */
    public function closeOrderReference($requestParameters = []);

    /**
     * @param array $requestParameters
     *
     * @return mixed
     */
    public function closeAuthorization($requestParameters = []);

    /**
     * @param array $requestParameters
     *
     * @return mixed
     */
    public function authorize($requestParameters = []);

    /**
     * Get the details of an existing payment transaction
     *
     * @param array $requestParameters
     *      requestParameters['hash_id'] - [String]
     *      requestParameters['payment_method'] - [String]
     *
     * @return ResponseParser
     */
    public function getAuthorizationDetails($requestParameters = []);

    /**
     * Capture a (pre)authorized payment transaction
     *
     * @param array $requestParameters
     *      requestParameters['capture_amount'] - [String]
     *      requestParameters['hash_id'] - [String]
     *
     * @return mixed
     */
    public function capture($requestParameters = []);

    /**
     * Get the details of an existing payment transaction
     *
     * @param array $requestParameters
     *      requestParameters['hash_id'] - [String]
     *      requestParameters['payment_method'] - [String]
     *
     * @return ResponseParser
     */
    public function getCaptureDetails($requestParameters = []);

    /**
     * @param array $requestParameters
     *
     * @return mixed
     */
    public function refund($requestParameters = []);

    /**
     * Get the details of an existing payment transaction
     *
     * @param array $requestParameters
     *      requestParameters['hash_id'] - [String]
     *      requestParameters['payment_method'] - [String]
     *
     * @return ResponseParser
     */
    public function getRefundDetails($requestParameters = []);

    /**
     * @param array $requestParameters
     *
     * @return mixed
     */
    public function getServiceStatus($requestParameters = []);
}
