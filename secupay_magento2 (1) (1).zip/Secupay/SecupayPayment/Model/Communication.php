<?php

namespace Secupay\SecupayPayment\Model;

use Magento\Customer\Model\Session;
use Magento\Framework\Api\AttributeValueFactory;
use Magento\Framework\Api\ExtensionAttributesFactory;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\App\ObjectManager;
use Magento\Framework\Model\Context;
use Magento\Framework\Model\ResourceModel\AbstractResource;
use Magento\Framework\Data\Collection\AbstractDb;
use Magento\Framework\Registry;
use Magento\Payment\Helper\Data;
use Magento\Payment\Model\Method\Logger;
use Magento\Quote\Model\Quote;
use Magento\Sales\Api\Data\TransactionInterface;
use SecucardConnect\Product\Payment\Model\PaymentInstrument;
use SecucardConnect\Product\Payment\Model\SecupayInvoice;
use SecucardConnect\Product\Payment\Model\SecupayPrepay;
use SecucardConnect\Product\Payment\Model\Transaction;
use SecucardConnect\Product\Payment\Model\TransferAccount;
use Secupay\SecupayPayment\Helper\Basket;
use Secupay\SecupayPayment\Helper\Config;
use Secupay\SecupayPayment\Helper\SecuconnectFactory;
use Secupay\SecupayPayment\Helper\TransactionHelper;
use Magento\Quote\Model\Quote\Address;
use Magento\Payment\Model\Method\AbstractMethod;
use Magento\Payment\Model\InfoInterface;

/**
 * Class Communication
 * @package Secupay\SecupayPayment\Model
 */
abstract class Communication extends AbstractMethod
{
    const PAYMENT_CODE = '';

    public $SecupayCustomerId;

    protected $_minAmount = null;
    protected $_maxAmount = null;

    private $_quote;

    /**
     * @var \Magento\Customer\Model\Session
     */
    private $customerSession;
    private $customerId;

    protected $_infoBlockType = 'Secupay\SecupayPayment\Block\Info';
    protected $_isOffline = false;
    protected $_isGateway = true;
    protected $_canAuthorize = false;
    protected $_canCapture = true;
    protected $_canCapturePartial = true;
    protected $_canRefund = true;
    protected $_canRefundInvoicePartial = true;
    protected $_canVoid = false;
    protected $_canUseInternal = false;
    protected $_canUseCheckout = true;
    protected $_isInitializeNeeded = true;
    protected $_canReviewPayment = false;
    protected $_canOrder = true;

    /**
     * @var DbConnector
     */
    protected $db;
    /**
     * @var \Secuconnect\Client
     */
    private $secuconnectClient;

    /**
     * Communication constructor.
     * @param Context $context
     * @param Registry $registry
     * @param ExtensionAttributesFactory $extensionFactory
     * @param AttributeValueFactory $customAttributeFactory
     * @param Data $paymentData
     * @param ScopeConfigInterface $scopeConfig
     * @param Logger $logger
     * @param AbstractResource|null $resource
     * @param AbstractDb|null $resourceCollection
     * @param array $data
     */
    public function __construct(
        Context $context,
        Registry $registry,
        ExtensionAttributesFactory $extensionFactory,
        AttributeValueFactory $customAttributeFactory,
        Data $paymentData,
        ScopeConfigInterface $scopeConfig,
        Logger $logger,
        AbstractResource $resource = null,
        AbstractDb $resourceCollection = null,
        array $data = []
    ) {
        $this->_code = static::PAYMENT_CODE;

        parent::__construct(
            $context,
            $registry,
            $extensionFactory,
            $customAttributeFactory,
            $paymentData,
            $scopeConfig,
            $logger,
            $resource,
            $resourceCollection,
            $data
        );

        $this->db = new DbConnector();

        $this->secuconnectClient = ObjectManager::getInstance()->get(SecuconnectFactory::class)->getSecuconnectClient();

        $this->customerSession = ObjectManager::getInstance()->get('Magento\Customer\Model\Session');
        $this->customerId = $this->customerSession->getCustomer()->getId();
        if (empty($this->customerId)) {
            $this->customerId = $this->_getQuote()->getCustomerId();
        }

        $this->initSecupayCustomerId();
    }

    private function initSecupayCustomerId()
    {
        // SecupayCustomerId already loaded (and validated)?
        if (empty($this->customerId) || !empty($this->SecupayCustomerId)) {
            return;
        }

        // SecupayCustomerId already save into the session?
        $secupayCustomerId = $this->_getQuote()->getSecupayCustomerId();
        if (!empty($secupayCustomerId)) {
            $this->SecupayCustomerId = $secupayCustomerId;
            return;
        }

        $this->_logger->debug(__METHOD__ . ' -> customerId: ' . $this->customerId);

        // For the next steps we need some customer data (firstname, lastname, email)
        if (is_null($this->_getQuote()->getBillingAddress()) && !empty($this->customerSession->getCustomer()->getEmail())) {
            return;
        }

        // Use the session data?
        if ($this->customerSession->isLoggedIn()) {

            $this->_logger->debug(__METHOD__ . ' -> use Magento\Customer\Model\Session');

            /**
             * @var \Magento\Customer\Model\Customer $customerData
             */
            $customerData = $this->customerSession->getCustomer();
            $secupayCustomerId = $this->db->getSecupayCustomerIdByShopCustomerId($this->customerId);
            $customerFirstname = $customerData->getFirstname();
            $customerLastname = $customerData->getLastname();
            $customerMail = $customerData->getEmail();

            $this->_logger->debug(__METHOD__ . ' -> loaded secupayCustomerId: ' . json_encode($secupayCustomerId));

            if (empty($secupayCustomerId)) {
                $secupayCustomerId = $this->secuconnectClient->getCustomerId(null, [
                    'email' => $customerMail,
                    'firstname' => $customerFirstname,
                    'lastname' => $customerLastname,
                ]);
                $this->db->saveSecupayCustomerId($this->customerId, $secupayCustomerId);
            } else {
                $new_id = $this->secuconnectClient->getCustomerId($secupayCustomerId, [
                    'email' => $customerMail,
                    'firstname' => $customerFirstname,
                    'lastname' => $customerLastname,
                ]);

                if ($new_id != $secupayCustomerId) {
                    $secupayCustomerId = $new_id;
                    $this->_logger->debug(__METHOD__ . ' -> updated secupayCustomerId: ' . json_encode($secupayCustomerId));
                    $this->db->updateSecupayCustomerIdByShopCustomerId($this->customerId, $secupayCustomerId);
                }
            }
        } else {
            $this->_logger->debug(__METHOD__ . ' -> use Magento\Checkout\Model\Session');

            // Use the checkout data
            $customerFirstname = $this->_getQuote()->getBillingAddress()->getFirstname();
            $customerLastname = $this->_getQuote()->getBillingAddress()->getLastname();
            $customerMail = $this->_getQuote()->getBillingAddress()->getEmail();
            $secupayCustomerId = $this->secuconnectClient->getCustomerId(null, [
                'email' => $customerMail,
                'firstname' => $customerFirstname,
                'lastname' => $customerLastname,
            ]);
        }

        $this->_getQuote()->setSecupayCustomerId($secupayCustomerId);
        $this->SecupayCustomerId = $secupayCustomerId;

        $this->_logger->debug(__METHOD__ . ' -> SecupayCustomerId :' . json_encode($this->SecupayCustomerId));
    }

    /**
     * @return bool
     */
    public function canUseCheckout()
    {
        return parent::canUseCheckout();
    }

    /**
     * @return Quote
     */
    protected function _getQuote()
    {
        if (is_null($this->_quote)) {
            $this->_quote = ObjectManager::getInstance()->get(
                'Magento\Checkout\Model\Session'
            )->getQuote();
        }

        return $this->_quote;
    }

    /**
     * @param string $paymentAction
     * @param object $stateObject
     * @return $this|bool
     */
    public function initialize($paymentAction, $stateObject)
    {
        parent::initialize($paymentAction, $stateObject);

        $redirect = $this->paymentRequest();
        if ($redirect === false || empty($redirect['iframe_url'])) {
            return false;
        }

        $this->getSession()->setPaymentUrl($redirect['iframe_url']);
        $this->getInfoInstance()->setAdditionalInformation(
            'secupay_transaction_id',
            $redirect['id']
        );

        return $this;
    }

    /**
     * @return Session
     */
    private function getSession()
    {
        return ObjectManager::getInstance()->get('Magento\Customer\Model\Session');
    }

    /**
     * @return \Psr\Log\LoggerInterface
     */
    protected function getLogger()
    {
        return ObjectManager::getInstance()->get('\Psr\Log\LoggerInterface');
    }

    /**
     * @return array|false|null|string
     */
    private function paymentRequest()
    {
        $this->_logger->debug(__METHOD__ . ' -> args: ' . json_encode(func_get_args()));
        $orderId = $this->_getQuote()->getReservedOrderId();
        $ShippingAddress = $this->_getQuote()->getShippingAddress();
        $BillingAddress = $this->_getQuote()->getBillingAddress();
        $grandTotal = $this->_getQuote()->getGrandTotal();
        $amount = round($grandTotal, 2) * 100;
        $paymentMethod = $this->_getQuote()->getPayment()->getMethod();
        $secupayCustomerId = $this->_getQuote()->getSecupayCustomerId();
        $this->_logger->debug(__METHOD__ . ' -> $secupayCustomerId: ' . json_encode($secupayCustomerId));

       $demomode = (int)Config::getConfigValue(
           Config::DEMO_MODE
       );

        if ($this->customerId) {
            $sqlp = "SELECT count(entity_id) AS count FROM " . $this->db->getTableName('sales_order') . " WHERE customer_id = '" . $this->customerId . "'  AND status = 'processing' OR customer_id = '" . $this->customerId . "'  AND status = 'closed' OR customer_id = '" . $this->customerId . "'  AND status = 'Complete' ";
            $sqln = "SELECT count(entity_id) AS count FROM " . $this->db->getTableName('sales_order') . " WHERE customer_id = '" . $this->customerId . "'";
            $positive = $this->db->getConnection()->fetchAll($sqlp);
            $positive = $positive[0]['count'];
            $this->_logger->debug(__METHOD__ . ' -> args: isLoggedIn $positive' . print_r($positive, true));
            $all = $this->db->getConnection()->fetchAll($sqln);
            $all = $all[0]['count'];
            $negative = $all - $positive;
        } else {
            $positive = 0;
            $negative = 0;
        }

        $basketClass = new Basket();

        $set_accrual = 0; // TODO for later

        $locale = ObjectManager::getInstance()->get('Magento\Framework\Locale\Resolver')->getLocale();
        $this->_logger->debug(__METHOD__ . ' -> $locale: ' . json_encode($locale));

        switch ($locale) {
            case 'de_DE':
            case 'de_AT':
            case 'ch_DE':
                $lang = "de_de";
                break;
            case 'en_US':
                $lang = "en_us";
                break;
            /*case 'nl':
                $lang = "nl_nl/";
                break;
            case 'fr':
                $lang = "fr_fr/";
                break;
            case 'it':
                $lang = "it_it/";
                break;
            case 'ru':
                $lang = "ru_ru/";
                break;*/
            default:
                $lang = 'en_us';
        }

        $storeManager = ObjectManager::getInstance()->get('\Magento\Store\Model\StoreManagerInterface');
        $purpose = "Bestellung bei " . $storeManager->getStore()->getName() . "|vom " . date("d.m.Y") . "| Bestell-Nr: " . $orderId;

        $subscription_id = null;    // TODO add id
        $subscription_purpose = null;   // $purpose

        $billing_address = [
            'email' => $this->_getQuote()->getCustomerEmail(),
            'dob' => $this->_getQuote()->getCustomerDob(),
            'gender' => $this->_getQuote()->getCustomerGender(),
            'title' => $BillingAddress->getPrefix(),
            'firstname' => $BillingAddress->getFirstname(),
            'lastname' => $BillingAddress->getLastname(),
            'company' => $BillingAddress->getCompany(),
            'street' => $BillingAddress->getStreetFull(),
            'zip' => $BillingAddress->getPostcode(),
            'city' => $BillingAddress->getCity(),
            'country' => $BillingAddress->getCountryId(),
            'telephone' => $BillingAddress->getTelephone(),
            'merchant_customer_id' => $this->_getQuote()->getCustomerId(),
        ];

        // Save/Update the customer address
        $res = $this->secuconnectClient->updateCustomer($secupayCustomerId, $billing_address);

        if (!$res) {
            $this->_logger->debug(__METHOD__ . ' -> error on updateCustomer(billing_address)');
            return false;
        }

        $secupayCustomerId = $res;
        if ($this->customerId) {
            $this->db->saveSecupayCustomerId($this->customerId, $secupayCustomerId);
        }

        //check if $shipping is object, for basket with only virtual products getShippingAddress returns null
        $recipient_id = null;
        if ($ShippingAddress instanceof Address && $this->getDifferentShippingAddress()) {
            $delivery_address = [
                'email' => $ShippingAddress->getEmail(),
                'dob' => null,
                'gender' => null,
                'title' => $ShippingAddress->getPrefix(),
                'firstname' => $ShippingAddress->getFirstname(),
                'lastname' => $ShippingAddress->getLastname(),
                'company' => $ShippingAddress->getCompany(),
                'street' => $ShippingAddress->getStreetFull(),
                'zip' => $ShippingAddress->getPostcode(),
                'city' => $ShippingAddress->getCity(),
                'country' => $ShippingAddress->getCountryId(),
                'telephone' => $ShippingAddress->getTelephone(),
                'merchant_customer_id' => $this->_getQuote()->getCustomerId(),
            ];

            // Save the customer address
            $res = $this->secuconnectClient->updateCustomer(null, $delivery_address);

            if (!$res) {
                $this->_logger->debug(__METHOD__ . ' -> error on updateCustomer(delivery_address)');
                $this->_redirect('checkout/cart/');
            }

            $recipient_id = $res;
        }

        $uniqueId = $this->createUniqueId();
        $data = [
            'payment_action' => 'sale',
            'payment_method' => $paymentMethod,
            'demo' => $demomode,
            // TODO
            'customer_id' => $secupayCustomerId,
            'recipient_id' => $recipient_id,
            'shop' => 'Magento',
            'shopversion' => 'Magento ' . ObjectManager::getInstance()->get('Magento\Framework\App\ProductMetadataInterface')->getVersion(),
            'amount' => $amount,
            'currency' => $this->_getQuote()->getCurrency()->getQuoteCurrencyCode(),
            'order_id' => $orderId,
            'purpose' => $purpose,
            'url_push' => ObjectManager::getInstance()->get('Magento\Framework\UrlInterface')->getUrl(
                'secuconnect/payment/notification',
                [
                    'orderId' => $orderId,
                    'uid' => $uniqueId,
                    'cardId' => $basketClass->getCartId()
                ]),
            'url_success' => ObjectManager::getInstance()->get('Magento\Framework\UrlInterface')->getUrl(
                'secuconnect/payment/success',
                [
                    'orderId' => $orderId,
                    'uid' => $uniqueId,
                    'cardId' => $basketClass->getCartId()
                ]),
            'url_failure' => ObjectManager::getInstance()->get('Magento\Framework\UrlInterface')->getUrl(
                'secuconnect/payment/failure',
                [
                    'orderId' => $orderId,
                    'uid' => $uniqueId,
                    'cardId' => $basketClass->getCartId()
                ]),
            'positive' => $positive,
            'negative' => $negative,
            'set_accrual' => $set_accrual,
            'basket' => $basketClass->getBasketInformation(),
            'subscription_id' => $subscription_id,
            'subscription_purpose' => $subscription_purpose
        ];
        $this->_logger->notice(__METHOD__ . ' -> data: ' . print_r($data, true));

        $this->db->savePaymentInformation('new', $data + ['billing_address' => $billing_address], $paymentMethod,
            $uniqueId, $orderId, $amount, null, null, null, null);

        $this->_logger->debug('paymentRequest call authorize');
        $res = $this->secuconnectClient->authorize($data);

        if (!$res) {
            $this->_logger->debug(__METHOD__ . ' -> error on authorize()');
            $this->_redirect('checkout/cart/');
        }

        $this->db->savePaymentInformation('update', null, null, null, $orderId, null, null, $res['id'],
            json_encode($res), 'created');
        $this->_logger->debug(__METHOD__ . ' -> $res: ' . json_encode($res));

        return $res;
    }

    /**
     * @return string
     */
    protected function createUniqueId()
    {
        return md5(uniqid(mt_rand(), true));
    }

    /**
     * Get initialized flag status
     *
     * @return bool true
     */
    public function isInitializeNeeded()
    {

        return $this->_isInitializeNeeded;
    }

    /**
     * @param string $rawBody
     *
     * @return array
     */
    public function getStatusData($rawBody)
    {
        $this->_logger->debug(__METHOD__ . ' -> args: ' . json_encode(func_get_args()));

        $transactionData = ['status' => 'internal_server_status'];

        try {
            $this->secuconnectClient->handlePaymentChangeEvent($rawBody);

            $transaction = $this->secuconnectClient->pushed_transaction;
            $this->_logger->debug(__METHOD__ . ' -> $transaction: ' . print_r($transaction, true));

            if ($transaction instanceof Transaction) {
                $transactionData['status'] = $transaction->status; // f.e. "authorized"
                $transactionData['amount'] = $transaction->amount;
                $transactionData['transaction_status'] = $transaction->transaction_status; // f.e. "25"
                $transactionData['amount_refunded'] = 0; // currently not supported
                $transactionData['transaction_id'] = $transaction->id; // f.e. "ufgjjwdfmwph1468032"
                $transactionData['trans_id'] = $transaction->trans_id; // f.e. "7867851"

                if ($transaction->used_payment_instrument instanceof PaymentInstrument) {
                    $transactionData['payment_instrument']['type'] = $transaction->used_payment_instrument->type; // "bank_account" or "credit_card"
                    $transactionData['payment_instrument']['data'] = $transaction->used_payment_instrument->data;
                    // data for type "bank_account": 'owner', 'iban', 'bic', 'bankname'
                    // data for type "credit_card": 'owner', 'pan', 'expiration_date', 'issuer'
                }

                if ($transaction instanceof SecupayPrepay || $transaction instanceof SecupayInvoice) {
                    $transactionData['transfer_account'] = [];
                    $transactionData['transfer_purpose'] = $transaction->transfer_purpose; // f.e. "TA 7867851"

                    if ($transaction->transfer_account instanceof TransferAccount) {
                        $transactionData['transfer_account']['account_owner'] = $transaction->transfer_account->account_owner; // f.e. "secupay AG"
                        $transactionData['transfer_account']['accountnumber'] = $transaction->transfer_account->accountnumber; // f.e. "1747013"
                        $transactionData['transfer_account']['iban'] = $transaction->transfer_account->iban; // f.e. "DE88300500000001747013"
                        $transactionData['transfer_account']['bic'] = $transaction->transfer_account->bic; // f.e. "WELADEDDXXX"
                        $transactionData['transfer_account']['bankcode'] = $transaction->transfer_account->bankcode; // f.e. "30050000"
                    }
                }
            }
        } catch (\Exception $e) {
            $this->_logger->error(__METHOD__ . ' -> $e: ' . json_encode($e->getMessage()));
        }

        return $transactionData;
    }

    /**
     * @param string $orderId
     * @return mixed
     */
    public function getTransactionData($orderId)
    {
        return ObjectManager::getInstance()->get(TransactionHelper::class)->getTransactionData($orderId);
    }

    /**
     * @param InfoInterface $payment
     * @param float $amount
     * @return bool
     */
    public function capture(InfoInterface $payment, $amount)
    {
        $this->_logger->debug(__METHOD__ . ' -> args: ' . json_encode(func_get_args()));
        $order = $payment->getOrder();

        $statusData = $this->getTransactionData($order->getIncrementId());
        $this->_logger->debug(__METHOD__ . ' -> args statusData: ' . json_encode($statusData));

        if ($statusData['status'] == 'accepted') {
            $payment->setTransactionId($statusData['trans_id']);
            $payment->setParentTransactionId($payment->getTransactionId());
            //$payment->setLastTransId($statusData['trans_id']);
            $payment->setAmountPaid($statusData['amount'] / 100);
            $payment->setIsTransactionClosed(true);
            $payment->addTransaction(TransactionInterface::TYPE_CAPTURE, null, true);
            $message = __('The authorized amount is %1.', ($statusData['amount'] / 100));
            //get the object of builder class
            $trans = ObjectManager::getInstance()->get('Magento\Sales\Model\Order\Payment\Transaction\BuilderInterface');
            $transaction = $trans->setPayment($payment)
                ->setOrder($order)
                ->setTransactionId($statusData['trans_id'])
                ->setAdditionalInformation(
                    [\Magento\Sales\Model\Order\Payment\Transaction::RAW_DETAILS => (array)$statusData]
                )
                ->setFailSafe(true)
                //build method creates the transaction and returns the object
                ->build(\Magento\Sales\Model\Order\Payment\Transaction::TYPE_CAPTURE);

            $payment->addTransactionCommentsToOrder(
                $transaction,
                $message
            );


            $payment->save();
            return true;
        }

        return false;
    }

    public function processBeforeRefund($invoice, $payment)
    {
        $this->_logger->debug(__METHOD__ . ' -> args: ' . json_encode(func_get_args()));
//        $payment->setRefundTransactionId($invoice->getTransactionId());
//        $invoice->setRequestedCaptureCase(self::CAPTURE_ONLINE);
        return $this;
    }

    /**
     * @param InfoInterface $payment
     * @param float $amount
     * @return bool
     */
    public function refund(InfoInterface $payment, $amount)
    {
        $this->_logger->debug(__METHOD__ . ' -> args: ' . json_encode(func_get_args()));
        return true;

        /*
        return $this->_payment($payment, $amount, \HpsTransactionType::REFUND);


        $order = $payment->getOrder();
        $order_id = $order->getIncrementId();
        $amount = $amount * 100;
        $paymentmethod = $order->getpayment()->getmethod();

        // todo refund
        return true;
        */
    }

    /**
     * @param InfoInterface $payment
     * @return bool
     */
    public function cancel(InfoInterface $payment)
    {
        $this->_logger->debug(__METHOD__ . ' -> args: ' . json_encode(func_get_args()));
        $order = $payment->getOrder();
        $hash = $this->db->searchOrder($order->getIncrementId(), 'ordernr');
        $this->_logger->debug(__METHOD__ . ' -> args: ' . json_encode($hash));

        return true;
    }

    /**
     * @return bool
     */
    public function getDifferentShippingAddress()
    {
        if ($this->_getQuote()->getShippingAddress()->getSameAsBilling()) {
            return false;
        }

        // check if they are really different
        if ($this->_getQuote()->getShippingAddress()->getCustomerAddressId() == $this->_getQuote()->getBillingAddress()->getCustomerAddressId()) {
            return false;
        }

        // TODO what to do if the shipping address is empty

        return true;
    }

    /**
     * @return string
     */
    public function getCurrencyCode()
    {
        return (string)$this->_getQuote()->getCurrency()->getQuoteCurrencyCode();
    }

    /**
     * Get payment title
     * @return string
     */
    public function getTitle()
    {
        return __(parent::getTitle());
    }
}
