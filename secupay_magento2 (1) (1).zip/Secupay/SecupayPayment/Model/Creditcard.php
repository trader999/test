<?php

namespace Secupay\SecupayPayment\Model;

use Secupay\SecupayPayment\Helper\Config;

/**
 * Class Creditcard
 * @package Secupay\SecupayPayment\Model
 */
class Creditcard extends Communication
{
    const PAYMENT_CODE = 'secupay_creditcard';

    /**
     * @return bool
     */
    public function canUseCheckout()
    {
        // Check if the delivery address can be different from the billing address
        $differentDelivery = Config::getConfigValue(Config::PAYMENT_CREDIT_CARD_DIFFERENT_DELIVERY_ADDRESS_ALLOWED);
        if ($this->getDifferentShippingAddress() && $differentDelivery == 1) {
            return false;
        }

        $currency = $this->getCurrencyCode();
        if (empty($currency)) {
            return false;
        }

        // Check if currency is supported by the contract
        $contractCurrencies = Config::getConfigValue(Config::PAYMENT_CREDIT_CARD_CURRENCIES_SUPPORTED);
        if (strpos($contractCurrencies, $currency) === false) {
            return false;
        }

        // Check if currency is activated by the merchant
        $activatedCurrencies = Config::getConfigValue(Config::PAYMENT_CREDIT_CARD_CURRENCIES_ACTIVE);
        if (strpos($activatedCurrencies, $currency) === false) {
            return false;
        }

        // Load min and max amount
        $this->_minAmount = Config::getConfigValue(Config::PAYMENT_CREDIT_CARD_MIN_ORDER_TOTAL);
        $this->_maxAmount = Config::getConfigValue(Config::PAYMENT_CREDIT_CARD_MAX_ORDER_TOTAL);

        return parent::canUseCheckout();
    }
}
