<?php

namespace Secupay\SecupayPayment\Model;

use Magento\Framework\App\ObjectManager;
use Magento\Customer\Model\Session;
use Magento\Framework\App\ResourceConnection;
use Psr\Log\LoggerInterface;

/**
 * Class DbConnector
 * @package Secupay\SecupayPayment\Model
 */
class DbConnector
{
    /**
     * @var \Magento\Framework\DB\Adapter\AdapterInterface
     */
    private $connection;

    /**
     * @var Session
     */
    private $customerSession;

    /**
     * @var ResourceConnection
     */
    private $_resources;

    /**
     * @var string
     */
    private $tableNameForSecupayCustomer;

    /**
     * @var string
     */
    private $SecupayTransactionsTable;

    /**
     * @var string
     */
    private $SecupayTrackingTable;

    /**
     * @var LoggerInterface
     */
    private $logger;

    /**
     * DbConnector constructor.
     */
    public function __construct()
    {
        // TODO use dependency injection
        $this->_resources = ObjectManager::getInstance()->get(ResourceConnection::class);
        $this->customerSession = ObjectManager::getInstance()->get(Session::class);
        $this->connection = $this->_resources->getConnection();
        $this->tableNameForSecupayCustomer = $this->_resources->getTableName('secupay_customer');
        $this->SecupayTransactionsTable = $this->_resources->getTableName('secupay_transactions');
        $this->SecupayTrackingTable = $this->_resources->getTableName('secupay_transaction_tracking');
        $this->logger = ObjectManager::getInstance()->get(LoggerInterface::class);
    }

    /**
     * Get resource table name, validated by db adapter
     *
     * @param string $name
     *
     * @return string
     */
    public function getTableName($name)
    {
        return (string)$this->_resources->getTableName($name);
    }

    public function savePaymentInformation( // TODO rework in v1.1
        $new,
        $req_data = null,
        $payment_type = null,
        $unique_id = null,
        $orderId = null,
        $amount = null,
        $trans_id = null,
        $hash = null,
        $ret_data = null,
        $status = null
    ) {
        $this->logger->debug(__METHOD__ . ' -> args: ' . json_encode(func_get_args()));
        if ($new == 'new') {
            $this->logger->debug(__METHOD__ . ' -> args: ' . json_encode('new'));
            try {
                $this->getConnection()->insertArray(
                    $this->SecupayTransactionsTable,
                    [
                        'req_data',
                        'payment_type',
                        'unique_id',
                        'ordernr',
                        'amount',
                    ],
                    [
                        [
                            json_encode($req_data),
                            $payment_type,
                            $unique_id,
                            $orderId,
                            $amount
                        ]
                    ]
                );
            } catch (\Exception $e) {
                $this->logger->debug(__METHOD__ . ' -> $e: ' . json_encode($e));
            }
        }
        if ($new == 'update' && !empty($orderId)) {
            $this->logger->debug(__METHOD__ . ' -> args: ' . json_encode('update'));
            try {
                $sql = "update " . $this->SecupayTransactionsTable . " set hash = '" . $hash . "', ret_data = '" . $ret_data . "', status = 'created' WHERE ordernr='" . $orderId . "'";
                $this->getConnection()->rawQuery($sql);
            } catch (\Exception $e) {
                $this->logger->debug(__METHOD__ . ' -> $e: ' . json_encode($e));
            }
        }
        if ($new == 'failure' && !empty($orderId)) {
            $this->logger->debug(__METHOD__ . ' -> args: ' . json_encode('failure'));
            try {
                $sql = "update " . $this->SecupayTransactionsTable . " set status = 'failure' WHERE ordernr=" . $orderId;
                $this->getConnection()->rawQuery($sql);
            } catch (\Exception $e) {
                $this->logger->debug(__METHOD__ . ' -> $e: ' . json_encode($e));
            }
        }
        if ($new == 'success' && !empty($orderId)) {
            $this->logger->debug(__METHOD__ . ' -> args: ' . json_encode('success'));
            try {
                $sql = "update " . $this->SecupayTransactionsTable . " set status = 'pending', searchcode= '" . $orderId . "' WHERE ordernr=" . $orderId;
                $this->getConnection()->rawQuery($sql);
            } catch (\Exception $e) {
                $this->logger->debug(__METHOD__ . ' -> $e: ' . json_encode($e));
            }
        }
        if ($new == 'push' && !empty($orderId)) {
            $this->logger->debug(__METHOD__ . ' -> args: ' . json_encode('accepted'));
            try {
                $sql = "update " . $this->SecupayTransactionsTable . " set status = '" . $status . "', trans_id = '" . $trans_id . "'  WHERE ordernr='" . $orderId . "'";
                $this->getConnection()->rawQuery($sql);
            } catch (\Exception $e) {
                $this->logger->debug(__METHOD__ . ' -> $e: ' . json_encode($e));
            }
        }
    }

    /**
     * Retrieve connection to resource specified by default connection
     *
     * @return \Magento\Framework\DB\Adapter\AdapterInterface
     */
    public function getConnection()
    {
        return $this->_resources->getConnection();
    }

    /**
     * @param string $orderId
     * @param string $trackid
     * @param string $carrier
     * @return bool
     */
    private function saveTraqckingData($orderId, $trackid, $carrier)
    {
        $this->logger->debug(__METHOD__ . ' -> args: ' . json_encode(func_get_args()));

        return (bool)$this->getConnection()->update(
            $this->SecupayTransactionsTable,
            [
                'track_number' => (string)$trackid,
                'carrier_code' => (string)$carrier,
            ],
            ['ordernr = ?' => (string)$orderId]
        );
    }

    /**
     * @param string $new
     * @param string $orderId
     * @param string $trackid
     * @param string $carrier
     */
    public function saveTrackingInformation($new, $orderId = null, $trackid = null, $carrier = null)
    {
        $this->logger->debug(__METHOD__ . ' -> args: ' . json_encode(func_get_args()));
        if ($new == 'track' && !empty($orderId)) {
            $iftracking = self::searchOrder($orderId, 'track_number');
            $hash = self::searchOrder($orderId, 'hash');
            $this->logger->debug(__METHOD__ . ' -> args: ' . json_encode('accepted'));

            $v_send = null;

            if (empty($iftracking)) {
                $this->saveTraqckingData($orderId, $trackid, $carrier);
            } else {
                // todo insert tracking table
                try {
                    $this->getConnection()->insertArray(
                        $this->SecupayTrackingTable,
                        [
                            'hash',
                            'tracking_code',
                            'carrier_code',
                            'v_send',

                        ],
                        [
                            [
                                $hash,
                                $trackid,
                                $carrier,
                                $v_send
                            ]
                        ]
                    );
                } catch (\Exception $e) {
                    $this->logger->debug(__METHOD__ . ' -> $e: ' . json_encode($e));
                }
            }
        }

        if ($new == 'send' && !empty($orderId)) {
            $iftracking = self::searchOrder($orderId, 'track_number');
            $hash = self::searchOrder($orderId, 'hash');
            $this->logger->debug(__METHOD__ . ' -> args: ' . json_encode('accepted'));
            try {
                if (empty($iftracking)) {
                    $sql = "update " . $this->SecupayTransactionsTable . " set v_send = '1' WHERE ordernr = '" . $orderId . "'";
                    $this->logger->debug(__METHOD__ . ' -> args: ' . json_encode(print_r($sql, true)));
                    $this->getConnection()->rawQuery($sql);
                } else {
                    // tudo update tracking table v_send
                    $sql = "update " . $this->SecupayTrackingTable . " set v_send = '1' WHERE hash ='" . $hash . "'";
                    $this->getConnection()->rawQuery($sql);

                }
            } catch (\Exception $e) {
                $this->logger->debug(__METHOD__ . ' -> $e: ' . json_encode($e));
            }
        }
        if ($new == 'invoice' && !empty($orderId)) {
            $this->logger->debug(__METHOD__ . ' -> args: ' . json_encode('success'));
            try {
                $sql = "update " . $this->SecupayTransactionsTable . " set status = 'pending', searchcode= '" . $trackid . "' WHERE ordernr=" . $orderId;
                $this->getConnection()->rawQuery($sql);
            } catch (\Exception $e) {
                $this->logger->debug(__METHOD__ . ' -> $e: ' . json_encode($e));
            }
        }
    }

    /**
     * @param int $orderId
     * @param string|array $searchField
     * @param bool|string $created
     *
     * @return null
     */
    public function searchOrder($orderId, $searchField, $created = false)
    {
        $this->logger->debug(__METHOD__ . ' -> args: ' . json_encode(func_get_args()));

        // Convert the input params
        if (is_array($searchField)) {
            $returnOnlyOneField = false;
            $selectExpr = $searchField;
        } else {
            $returnOnlyOneField = true;
            $selectExpr = [$searchField];
        }

        // Build the sql query
        $selectExpr = implode("`, `", $selectExpr);

        if (empty($created)) {
            $sql = "SELECT `" . $selectExpr . "`
                    FROM `" . $this->SecupayTransactionsTable . "`
                    WHERE ordernr = " . $this->getConnection()->quote($orderId) . "
                    LIMIT 1";
        } else {
            $sql = "SELECT `" . $selectExpr . "`
                    FROM `" . $this->SecupayTransactionsTable . "`
                    WHERE ordernr = " . $this->getConnection()->quote($orderId) . "
                      AND status IN ('created','denied')
                    LIMIT 1";
        }

        // Execute the sql query
        $this->logger->debug(__METHOD__ . ' -> $sql: ' . json_encode($sql));
        $result = $this->getConnection()->fetchRow($sql);
        $this->logger->debug(__METHOD__ . ' -> $result: ' . json_encode($result));

        // Return the response (all fields or only the one)
        if ($returnOnlyOneField) {
            return empty($result[$searchField]) ? null : $result[$searchField];
        }

        return empty($result) ? null : (array)$result;
    }

    /**
     * Search for the secupay customer id by using the given shop customer id
     * TODO move to Helper.Model.Customer
     *
     * @param string $shopCustomerId
     * @return string|null
     */
    public function getSecupayCustomerIdByShopCustomerId($shopCustomerId)
    {
        $this->logger->debug(__METHOD__ . ' -> args: ' . json_encode(func_get_args()));

        $select = $this->getConnection()->select();
        $select
            ->from($this->tableNameForSecupayCustomer, 'secupay_customer_id')
            ->where('customer_id = :customer_id');

        $secupayCustomerId = $this->getConnection()->fetchOne($select, ['customer_id' => (string)$shopCustomerId]);

        return empty($secupayCustomerId) ? null : $secupayCustomerId;
    }

    /**
     * Update the secupay customer id for a given shop customer id
     * TODO move to Helper.Model.Customer
     *
     * @param string $shopCustomerId
     * @param string $secupayCustomerId
     * @return bool TRUE If some data was changed, FALSE otherwise
     */
    public function updateSecupayCustomerIdByShopCustomerId($shopCustomerId, $secupayCustomerId)
    {
        $this->logger->debug(__METHOD__ . ' -> args: ' . json_encode(func_get_args()));

        return (bool)$this->getConnection()->update(
            $this->tableNameForSecupayCustomer,
            ['secupay_customer_id' => (string)$secupayCustomerId],
            ['customer_id = ?' => (string)$shopCustomerId]
        );
    }

    /**
     * Saves a new secupay customer id for a given shop customer id
     * TODO move to Helper.Model.Customer
     *
     * @param string $secupayCustomerId
     * @param int $customerId
     * @return bool TRUE If some data was inserted, FALSE otherwise
     */
    public function saveSecupayCustomerId($customerId, $secupayCustomerId)
    {
        $this->logger->debug(__METHOD__ . ' -> args: ' . json_encode(func_get_args()));

        return (bool)$this->getConnection()->insertOnDuplicate(
            $this->tableNameForSecupayCustomer,
            [
                [
                    'customer_id' => (string)$customerId,
                    'secupay_customer_id' => (string)$secupayCustomerId
                ]
            ]
        );
    }
}
