<?php
/**
 * secupay Payment Module
 *
 * Copyright (c) 2017 secupay AG
 *
 * @category  Payment
 * @author    secupay AG
 * @copyright 2017, secupay AG
 * @link      https://www.secupay.ag/de/online-commerce/shopmodule
 * @license  MIT / X11 License
 * Description:
 *
 * Magento module for integration of secupay AG payment services
 *
 * NOTICE OF LICENSE
 *
 * Licensed under the MIT / X11 License (the "License");
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

namespace Secupay\SecupayPayment\Model\Method;

use Magento\Framework\DataObject;
use Magento\Payment\Model\InfoInterface;
use Magento\Payment\Model\Method\AbstractMethod;

/**
 * Class SecuConnect
 * @package Secupay\SecupayPayment\Model\Method
 */
class SecuConnect extends AbstractMethod
{
    /**
     * {@inheritdoc}
     */
    public function authorize(InfoInterface $payment, $amount)
    {
    }

    /**
     * {@inheritdoc}
     */
    public function authorizeInCron(InfoInterface $payment, $amount, $capture)
    {
    }

    /**
     * {@inheritdoc}
     */
    public function capture(InfoInterface $payment, $amount)
    {
    }

    /**
     * {@inheritdoc}
     */
    public function refund(InfoInterface $payment, $amount)
    {
    }

    /**
     * {@inheritdoc}
     */
    public function assignData(DataObject $data)
    {
        $additionalData = $data->getAdditionalData();

        if (!is_array($additionalData)) {
            return $this;
        }

        $additionalData = new DataObject($additionalData);

        $infoInstance = $this->getInfoInstance();
        $key = AdditionalInformation::KEY_SANDBOX_SIMULATION_REFERENCE;
        $infoInstance->setAdditionalInformation($key, $additionalData->getData($key));

        return $this;
    }
}
