<?php

namespace Secupay\SecupayPayment\Observer;

use Magento\Framework\App\ObjectManager;
use Magento\Framework\Event\Observer as EventObserver;
use Magento\Framework\Event\ObserverInterface as MageObserverInterface;
use Psr\Log\LoggerInterface as Logger;
use Secupay\SecupayPayment\Helper\SecuconnectFactory;
use Secupay\SecupayPayment\Helper\Config;

/**
 * Class ConfigObserver
 * @package Secupay\SecupayPayment\Observer
 */
class ConfigObserver implements MageObserverInterface
{
    /**
     * @var Logger
     */
    protected $logger;

    /**
     * @var \Secuconnect\Client
     */
    private $secuconnectClient;

    /**
     * @param Logger $logger
     */
    public function __construct(Logger $logger)
    {
        $this->logger = $logger;
        $this->secuconnectClient = ObjectManager::getInstance()->get(SecuconnectFactory::class)->getSecuconnectClient();
    }

    /**
     * @param EventObserver $observer
     */
    public function execute(EventObserver $observer)
    {
        $this->logger->debug(__METHOD__ . ' -> args: ' . json_encode(func_get_args()));

        $helper = $this->secuconnectClient;
        try {
            $paymentMethods = $helper->getPaymentMethods();
        } catch (\Exception $e) {
            $this->logger->warning('No payment methods are active (' . $e->getMessage() . ')');
            $paymentMethods = [];
        }
        $this->logger->info('result of $payment_methods: ' . print_r($paymentMethods, true));

        $store = ObjectManager::getInstance()->get('Magento\Store\Model\Store');
        $scopeId = $store->getId();

        $supportedPaymentMethodsByModule = [
            'creditcard',
            'debit',
            'invoice',
            'prepay',
         //   'sofort',
            'paypal',
        ];

        foreach ($supportedPaymentMethodsByModule as $name) {
            if (!in_array($name, $paymentMethods)) {
                // nicht aktiv
                if ($scopeId > 0) {
                    // mit store
                    Config::saveConfigValue(
                        'payment/secupay_' . $name . '/active',
                        '0',
                        Config::SCOPE_STORE,
                        $scopeId
                    );
                } else {
                    // ohne store (default)
                    Config::saveConfigValue(
                        'payment/secupay_' . $name . '/active',
                        '0'
                    );
                }
            } else {
                // aktiv
                try {
                    $currencies = $helper->getCurrencies(['payment_method' => 'secupay_' . $name]);
                    $this->logger->info('result of $currencies: ' . json_encode($currencies));
                } catch (\Exception $e) {
                    $this->logger->warning('No currencies are active (' . $e->getMessage() . ')');
                    $currencies = [];
                }

                // nicht aktiv
                if ($scopeId > 0) {
                    // mit store
                    Config::saveConfigValue(
                        'payment/secupay_' . $name . '/contractcurrency',
                        implode(',', $currencies),
                        Config::SCOPE_STORE,
                        $scopeId
                    );
                } else {
                    // ohne store (default)
                    Config::saveConfigValue(
                        'payment/secupay_' . $name . '/contractcurrency',
                        implode(',', $currencies)
                    );
                }
            }
        }
    }
}
