<?php

namespace Secupay\SecupayPayment\Observer;

use Psr\Log\LoggerInterface;
use Secupay\SecupayPayment\Helper\SecuconnectFactory;
use Secupay\SecupayPayment\Model\DbConnector;
use Magento\Framework\Event\Observer;

/**
 * Interface ObserverInterface
 * @package Secupay\SecupayPayment\Observer
 */
interface ObserverInterface extends \Magento\Framework\Event\ObserverInterface
{
    /**
     * ObserverInterface constructor.
     * @param LoggerInterface $logger
     * @param DbConnector $dbConnector
     * @param SecuconnectFactory $clientFactory
     */
    public function __construct(LoggerInterface $logger, DbConnector $dbConnector, SecuconnectFactory $clientFactory);

    /**
     * @param Observer $observer
     * @return bool
     */
    public function execute(Observer $observer);
}