<?php

namespace Secupay\SecupayPayment\Observer;

use Magento\Framework\Event\Observer;
use Secupay\SecupayPayment\Helper\Config;

/**
 * Class SalesOrderInvoiceSaveAfter
 * @package Secupay\SecupayPayment\Observer
 */
class SalesOrderInvoiceSaveAfter extends ObserverAbstract
{
    /**
     * @param Observer $observer
     * @return bool
     */
    public function execute(Observer $observer)
    {
        $active = Config::getConfigValue(Config::PAYMENT_INVOICE_SEND_INVOICE_NUMBER);

        if ($active == 1) {
            $invoiceId = $observer->getInvoice()->getIncrementId();
            $order_id = $observer->getInvoice()->getOrder()->getIncrementId();

            $this->dbConnector->saveTrackingInformation('invoice', $order_id, $invoiceId);
        }

        return true;
    }
}
