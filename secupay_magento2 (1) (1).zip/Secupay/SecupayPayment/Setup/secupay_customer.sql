CREATE TABLE IF NOT EXISTS `secupay_customer` (
  `entity_id`           INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `customer_id`         VARCHAR(255)     NOT NULL,
  `secupay_customer_id` VARCHAR(255)              DEFAULT NULL,
  `created`             TIMESTAMP        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated`             TIMESTAMP        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`entity_id`),
  UNIQUE KEY `key_customer_id` (`customer_id`) USING HASH
)
  ENGINE = InnoDB
  DEFAULT CHARSET = utf8;